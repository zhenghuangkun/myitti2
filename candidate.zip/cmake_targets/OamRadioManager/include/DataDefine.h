/*
 * DataDefine.h
 *
 *  Created on: 2019年8月19日
 *      Author: huangzhiwei
 */

#ifndef DATADEFINE_H_
#define DATADEFINE_H_

#pragma pack(push,1)

#define BMCP_CB_DEVICE_INFO 312101
typedef struct {
	Uint32 lanID;
	char modelName[64];
	char serialNumber[64];
	char hardwareVersion[64];
	char softwareVersion[64];
	Uint32 status;
} S_CBDeviceInfo;

#define BMCP_SW_DEVICE_INFO 312102
typedef struct {
	Uint32 lanID;
	char modelName[64];
	char serialNumber[64];
	char hardwareVersion[64];
	char softwareVersion[64];
	Uint32 status;
} S_SWDeviceInfo;

#define BMCP_DP_DEVICE_INFO 312103
typedef struct {
	Uint32 lanID;
	char modelName[64];
	char serialNumber[64];
	char hardwareVersion[64];
	char softwareVersion[64];
	Uint32 status;
} S_DPDeviceInfo;


#define BMCP_ALARM_PARAM 312104
typedef struct {
	Uint32 alarmID;
	bool alarmStatus;
	char alarmCause[256];
} S_AlarmParam;


#define BMCP_CELL_PARAM 312105
typedef struct {
	Uint32 arfcn;
	Uint32 phyCellId;
	Uint32 subFrameAssignment;
	Uint32 specialSubframePatterns;
	Uint32 bandwidth;
	Uint32 antenna;
} S_CellParam;

#define BMCP_PA_PARAM 312106
typedef struct {
	Uint32 lanID;
	Uint32 paStatus;
} S_PAParam;

#define BMCP_POWER_PARAM 312107
typedef struct {
	Uint32 lanID;
	Uint32 targetPower;
} S_PowerParam;


#define BMCP_TIME_PARAM 312108
typedef struct {
	Uint32 timestamp;
	char localTimeZone[64];
} S_TimeParam;

#define BMCP_OPTICAL_PARAM    312109
typedef struct
{
	Uint32 OpticalPort;
	char SFPSerialNumber[32];
	char SFPManuDate[32];
	Uint32 SFPNotPresentIndicator;
	char SFPType[32];
	Uint32 SFPOpticalWavelength;
	char SFPSupportingDataRate[32];
	Uint32 SFPTxFaultIndicator;
	Uint32 SFPLOSIndicator;
	char SFPRxPower[32];
	char SFPTxPower[32];
	Uint32 SFPTemperature;
	char SFPSupplyVoltage[32];
	Uint32 SFPSupplyCurrent;
	Uint32 CPRILinkStatus;
	Uint32 SFPTempHighAlarm;
	Uint32 SFPTempLowAlarm;
	Uint32 SFPTXPowerHighAlarm;
	Uint32 SFPTXPowerLowAlarm;
	Uint32 SFPRXPowerHighAlarm;
	Uint32 SFPRXPowerLowAlarm;
} S_CBOptInfoParam;;


#define LRCP_ID_DEVICE_INFO   86001
typedef struct
{
    Char manufacturer[64];
    Char manufacturerOUI[8];
    Char modelName[64];
    Char productClass[64];
    Char serialNumber[64];
    Char hardwareVersion[64];
    Char softwareVersion[64];
    Char specVersion[64];
    Char ruType[64];
}OranLrcpDeviceInfo;

#define LRCP_ID_ALARM_INFO_BBU   86006
typedef struct{
    Uint32 alarmId;       /**  告警ID **/
    Uint16 alarmStatus;
    Char alarmCause[64];
    Char alarmName[128];
}LrcpAlarmInfo;


#define ORAN_LRCP_ID_TIME  86012
typedef struct
{
    Uint32 timestamp;
    Char localTimeZone[256];
}LrcpSetTime;

typedef struct
{
    Char DateTime[24];
    Char TimeZone[8];
    Char UpTime[32];
}LrcpLocalTime;

#define ORAN_LRCP_ID_CARRIER_CONFIGURATION  86402
typedef struct
{
    Uint32 carrierID;
    Int32  referencePower;
    Uint32 dlfreq;
    Uint32 ulfreq;
    Uint32 bandWidth;
    Uint32 RFChannalMask;
    Uint16 ULATT;
    Uint16 DLATT;
}LrcpCarrierConfig;


#define ORAN_LRCP_ID_RRU_CAPABILITIES   86602
typedef struct
{
    Uint32 antennaNumber;
    Uint32 carrierNumber;
    Char   supportedFreqBands[256];
    Char   supportedFreqRanges[256];
}LrcpRRUCapabilities;

#define ORAN_LRCP_ID_CPU_OCCUPY_STATUS  86604
typedef struct
{
    Uint32 occupyRate;
}OranLrcpCPUOccupyStatus;

#define  ORAN_LRCP_ID_GPS_STATUS 86611
typedef struct
{
    Uint32 Status;
    Char Longitude[32];
    Char Latitude[32];
    Uint32 NumberOfSatellites;
    Int32 SignalStrength;
    Char Time[32];
    Char Date[32];
    Char TimeOffset[32] ;
}OranLrcpGPSStaus;

#define  ORAN_LRCP_ID_TEMPRATUE_STATUS 86612
typedef struct
{
    Int32 PA1;
    Int32 PA2;
    Int32 MainChip;
}LrcpTempStatus;

#define  ORAN_LRCP_ID_ANTENNA_STATUS 86613
typedef struct
{
    Uint32 AntennaID;
    Int32 ForewardPower;
    Uint32 VSWR;
}OranLrcpAntennaStatus;

#define  ORAN_LRCP_ID_ANTENNA_CARRIER_STATUS 86614
typedef struct
{
    Uint32 AntennaID;
    Uint32 ANTCarrierID;
    Uint16 ULFIFOStatus;
    Uint16 DLFIFOStatus;
    Uint16 ULATT;
    Uint16 DLATT;
    Int16 RSSI;
    Int16 UldBFS;
    Int16 DldBFS;
    Int16 OutputPower;
}LrcpAntennaCarrierStatus;

#define  ORAN_LRCP_ID_ANT_MAX_OUTPUT_POWER 86405
typedef struct
{
    Uint32 AntennaID;
    Uint8 MaxOutputPower;
}AntMaxOutputPower;

#define  ORAN_LRCP_ID_PA_ENABLE 86406
typedef struct
{
    Uint32 PaID;
    bool Enable;
}PAEnable;

#define  ORAN_LRCP_ID_TDD_LTE_SLOT_CONFIG 86407
typedef struct
{
    Uint32 AntennaID;
    Uint8 SubFrameAssignmemt;
    Uint8 SpecialSubframePatterns;
}TddLteSlotConfig;

#define LRCP_ID_TRANSPARENT_MSG 87710
#define LRCP_ID_FILE_PUSH 86023
#define LRCP_ID_FILE_PUSH_CONFIRM 86024
#define LRCP_ID_FIRMWARE_ACTIVATION 86009
#define LRCP_ID_REBOOT 86005
#define LRCP_ID_LOG_UPLOAD 86004

#pragma pack(pop)

#endif /* DATADEFINE_H_ */
