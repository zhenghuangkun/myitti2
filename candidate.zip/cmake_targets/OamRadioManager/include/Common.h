/*
 * Common.h
 *
 *  Created on: 2020-2-13
 *      Author: liuzhiping
 */

#ifndef COMMON_H_
#define COMMON_H_
#include <functional>
#include <memory>


typedef signed char Int8;

typedef unsigned char Uint8;
typedef unsigned char Byte;

typedef char Char;

typedef short Int16;
typedef unsigned short Uint16;
typedef int Int32;
typedef unsigned int Uint32;
typedef float Float32;
typedef double Float64;

typedef long long Int64;
typedef unsigned long long Uint64;

typedef std::function<void(void)> CBConnectFunc;
typedef std::shared_ptr<CBConnectFunc> CBConnectFuncPtr;

typedef std::function<void(void)> CBOfflineFunc;
typedef std::shared_ptr<CBOfflineFunc> CBOfflineFuncPtr;

typedef std::function<void(Uint32 dataID, Uint8* pData, Uint32 len)> CBReportParamFunc;
typedef std::shared_ptr<CBReportParamFunc> CBReportParamFuncPtr;

typedef std::function<void(char* response)> CBGetParamFunc;
typedef std::shared_ptr<CBGetParamFunc> CBGetParamFuncPtr;

typedef std::function<void(Uint32 dataID, bool flag)> CBResponseParamFunc;
typedef std::shared_ptr<CBResponseParamFunc> CBResponseParamFuncPtr;

#endif /* COMMON_H_ */
