/*
 * RadioOAMManger.h
 *
 *  Created on: 2019年8月19日
 *      Author: huangzhiwei
 */

#ifndef RADIOOAMMANAGER_H_
#define RADIOOAMMANAGER_H_
#include "Common.h"
#include <string>

class RadioOAMManager
{
private:
	RadioOAMManager(void);
public:
	bool StartServer(const std::string& localIP, int localPort);
	void RegisterCBConnectFuncPtr(const CBConnectFuncPtr &funcPtr);
	void RegisterCBOfflineFuncPtr(const CBOfflineFuncPtr &funcPtr);
	void RegisterCBReportParamFuncPtr(const CBReportParamFuncPtr &funcPtr);
	void RegisterCBResponseParamFuncPtr(const CBResponseParamFuncPtr &funcPtr);
	void RegisterCBGetParamFuncPtr(const CBGetParamFuncPtr &funcPtr);

	bool ConfigCBParam(Uint32 dataID, Uint8* pData, Uint32 len);
	bool Upgrade(Uint32 Port, const std::string& packageFile);
	bool RebootDevice(Uint32 deviceType, Uint32 device);
	bool CollectLog(Uint32 Port, const std::string& logFilePath, Uint32 maxSize);
	bool GetRRUParam(Uint32 StructID);
	std::string ConfigDebugCmd(const std::string& cmd);
	std::string GetVersion(void);
	void Debug(bool debugSwitch);
	static RadioOAMManager& Instance();

	bool ActiceRRU();
	/*
	 *指定版本号的激活
	 */
	bool ActiceRRU(const std::string&  version);
};

#endif /* RADIOOAMMANAGER_H_ */
