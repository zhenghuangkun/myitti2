#ifndef _GET_LIB_FUNCTION_H_
#define _GET_LIB_FUNCTION_H_


typedef signed char Int8;
typedef unsigned char Uint8;
typedef unsigned char Byte;
typedef char Char;
typedef short Int16;
typedef unsigned short Uint16;
typedef int Int32;
typedef unsigned int Uint32;
typedef float Float32;
typedef double Float64;
typedef long long Int64;
typedef unsigned long long Uint64;
typedef unsigned char bool;
#define true 1
#define false 0

#include "include/DataDefine.h"

typedef enum {
    Normal = 1,
    Offline,
    Warning,
    Upgrading
}Status_e;

char * DeviceStatusName[]={
    "Normal",
    "Offline",
    "Warning",
    "Upgrading"
};

typedef enum {
    CB_OpticalSyncAbnorml = 20001,
    CP_Optical_Lost,
    CB_GPS_Abnormality,
    CB_PLL_Lost_Lock,
    CB_FirmwareUpgradeFailure,
    SW_OpticalMainSyncAbnorml = 20010,
    SW_OpticalAccessorySyncAbnormal,
    SW_FirmwareUpgradeFailure,
    SW_pRadio_FirmwareUpgradeFailure = 20020
}ALARM_ID_e;

char * CBAlarmName[]={
    "CB_OpticalSyncAbnorml",
    "CP_Optical_Lost",
    "CB_GPS_Abnormality",
    "CB_PLL_Lost_Lock",
    "CB_FirmwareUpgradeFailure",
};
char * SWAlarmName[]={
    "SW_OpticalMainSyncAbnorml",
    "SW_OpticalAccessorySyncAbnormal",
    "SW_FirmwareUpgradeFailure"
};
char * PRadioAlarmName[]={
    "SW_pRadio_FirmwareUpgradeFailure"
};


char *ReturnResult[]={
    "failed",
    "successed"
};

typedef enum {
        CB_IDLE = 0,
        CB_CONNECT
}CB_STATUS;

typedef struct {
  Uint8 sw_flag[4];
  Uint8 pradio_flag[4][8];
  Uint32 power_param;
  Uint32 dl_carrier_freq;
  S_CellParam cell_param;
} CB_INFO;

// signal codes from oam to enb
typedef enum {
    SIGNAL_OAM_STRAT_IND = 0,
    SIGNAL_ALL_PRADIO_0 = 1,
    SIGNAL_ALL_PRADIO_1 = 2,
    SIGNAL_ALL_PRADIO_3 = 3,
    SIGNAL_PART_PRADIO_0 = 4,
    SIGNAL_PART_PRADIO_1 = 5,
    SIGNAL_PART_PRADIO_3 = 6,
    SIGNAL_ONE_PRADIO_0 = 7,
    SIGNAL_ONE_PRADIO_1 = 8,
    SIGNAL_ONE_PRADIO_3 = 9,
    SIGNAL_CB_CELL_PARAM = 10,
    SIGNAL_ENB_EXIT = 43
} oam_to_enb_signal_code_e;

extern Uint32 call_C_StartServer(char* s,int i);
extern void call_C_RegisterCBConnectFuncPtr(void (*func)());
extern void call_C_RegisterCBOfflineFuncPtr(void (*func)());
extern void call_C_RegisterCBReportParamFuncPtr(void (*func)(Uint32, Uint8*, Uint32));
extern Uint32 call_C_ConfigCBParam(Uint32 dataID, Uint8* pData, Uint32 len);
extern Uint32 call_C_Upgrade(Uint32 Port,char *packageFile);
extern Uint32 call_C_RebootDevice(Uint32 deviceType, Uint32 device);
extern Uint32 call_C_CollectLog(Uint32 Port,char *logFilePath,Uint32 maxSize);
extern char* call_C_ConfigDebugCmd(char* s);
extern char* call_C_GetVersion();
extern void call_C_Debug(Uint32 debugSwitch);

#define get_status_name(status) status>=Normal&&status<=Upgrading?DeviceStatusName[status-Normal]:"Unknown status"
#define get_alarm_name(alarmID) (alarmID>=CB_OpticalSyncAbnorml&&alarmID<=CB_FirmwareUpgradeFailure)?CBAlarmName[alarmID-CB_OpticalSyncAbnorml]:((alarmID>=SW_OpticalMainSyncAbnorml&&alarmID<=SW_FirmwareUpgradeFailure)?SWAlarmName[alarmID-SW_OpticalMainSyncAbnorml]:((alarmID==SW_pRadio_FirmwareUpgradeFailure)?PRadioAlarmName[alarmID-SW_pRadio_FirmwareUpgradeFailure]:("Unknown alarm")))
#define get_return_result(ret) ret==0||ret==1?ReturnResult[ret]:"Unknown result"


#endif /* D_GET_LOIB_FUNCTION_H */
