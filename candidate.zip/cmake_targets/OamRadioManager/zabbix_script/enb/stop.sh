#!/bin/bash

echo "OFF" > $STATUS_FILE
sudo kill -2 `ps -aux|grep lte-softmodem|awk '{print $2}'`
sleep 1
ps -fe|grep lte-softmodem |grep -v grep
if [ $? -eq 0 ];then
  sudo kill -9 `ps -aux|grep lte-softmodem|awk '{print $2}'`
fi
echo "Stop lte-softmodem"
