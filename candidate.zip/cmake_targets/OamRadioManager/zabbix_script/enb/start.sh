#!/bin/bash
source enbenv

if [ $# -ne 1 ];
then
    echo "sudo ./start.sh [config file]"
    echo "    config file:must at $ENB_WORK_PATH"
    exit
fi

cd $LOG_PATH 
rm -rf *
cp $ENB_WORK_PATH/$1 .

echo "cd $ENB_WORK_PATH"
cd $ENB_WORK_PATH
echo "nohup sudo -E ./lte_build_oai/build/lte-softmodem -O $1 --log-mem $LOG_PATH/enb.log > /tmp/enb.log 2>&1 &"
nohup sudo -E ./lte_build_oai/build/lte-softmodem -O $1 --log-mem $LOG_PATH/enb.log > /tmp/enb.log 2>&1 &

#sleep 25
#grep -ran "got sync" /tmp/enb.log|grep -v grep
#if [ $? -eq 0 ];then
#	echo "lte-softmodem start successfully!"
#else
#	echo "lte-softmodem start failed!"
#fi

echo "ON" > $STATUS_FILE
