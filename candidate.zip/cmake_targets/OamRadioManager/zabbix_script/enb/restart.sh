#!/bin/bash

sudo ./stop.sh
sleep 2
./start.sh $1
