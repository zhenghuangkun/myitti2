#!/bin/bash
source enbenv

#echo $ZABBIX_SERVER_IP
#echo $ZABBIX_SERVER_USER_NAME
#echo $ZABBIX_SERVER_PASSWORD

if [ $# -ne 1 ];
then
    echo "sudo ./download.sh [download path]"
    exit
fi

cd $1

sudo rm -rf /tmp/smb
mkdir /tmp/smb
sudo mount -t cifs -o username=$ZABBIX_SERVER_USER_NAME,password=$ZABBIX_SERVER_PASSWORD //$ZABBIX_SERVER_IP/smbshare/zabbix/transfer /tmp/smb
sudo cp -r /tmp/smb/* .
sudo umount /tmp/smb
