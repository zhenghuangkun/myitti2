#!/bin/bash
source enbenv

echo Send log from $LOG_PATH to $ZABBIX_SERVER_IP/smbshare/zabbix/log/enb

cd $LOG_PATH
cp /var/log/syslog .
sudo zip enb_$(date +%Y%m%d%H%M%S).zip *

sudo rm -rf /tmp/smb
mkdir /tmp/smb
sudo mount -t cifs -o username=$ZABBIX_SERVER_USER_NAME,password=$ZABBIX_SERVER_PASSWORD //$ZABBIX_SERVER_IP/smbshare/zabbix/log/enb /tmp/smb
sudo cp $LOG_PATH/enb_*.zip /tmp/smb
sudo umount /tmp/smb

