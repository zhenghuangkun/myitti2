#!/bin/bash
source oamenv

if [ $# -ne 2 ];
then
    echo "sudo ./upgrade.sh [Port] [packageFile]"
    echo "    port:60006"
    echo "    packageFile:Full path name of upgrade package"
    exit
fi

echo "upgrade $1 $2" > $FIFO_FILE
sleep 0.5
cat $RESULT_LOG
