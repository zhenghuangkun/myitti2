#!/bin/bash
source oamenv

if [ $# -ne 6 ];
then
    echo "sudo ./cellparam.sh [arfcn] [phyCellId] [subFrameAssignment] [specialSubframePatterns] [bandwidth] [antenna]"
    echo "    arfcn:[38250,38650]"
    echo "    phyCellId:[0,503]"
    echo "    subFrameAssignment:[0,6]"
    echo "    specialSubframePatterns:[0,8]"
    echo "    bandwidth:[0,100]"
    echo "    antenna:[1(Single antenna),2(Dual antenna)]"
    exit
fi

echo "cellparam $1 $2 $3 $4 $5 $6" > $FIFO_FILE
sleep 1
cat $RESULT_LOG
