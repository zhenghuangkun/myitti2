#!/bin/bash
source oamenv

cd $LOG_PATH 
rm -rf *

echo "cd $OAM_WORK_PATH"
cd $OAM_WORK_PATH
echo "nohup ./OAMRadioManager > /etc/oai/oam.log 2>&1 &"
nohup ./OAMRadioManager > /etc/oai/oam.log 2>&1 &
echo "ON" > $STATUS_FILE
