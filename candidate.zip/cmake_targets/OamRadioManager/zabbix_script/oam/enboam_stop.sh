#!/bin/bash

sudo systemctl stop oaienb
sudo systemctl stop oam
