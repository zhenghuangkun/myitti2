#!/bin/bash

cd /etc/oai

if [ -f alarm_count.txt ]; then
  sudo rm -fr alarm_count.txt
fi

if [ -f offline_count.txt ]; then
  sudo rm -fr offline_count.txt
fi

sudo systemctl start oaienb
sudo systemctl start oam
