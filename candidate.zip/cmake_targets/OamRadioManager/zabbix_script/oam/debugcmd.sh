#!/bin/bash
source oamenv

if [ $# -eq 0 ];
then
    echo "sudo ./debugcmd.sh [cmd] [arg...]"
    echo "    cmd:collect"
    exit
fi

echo "debugcmd $1 $2 $3" > $FIFO_FILE
sleep 5
cat $RESULT_LOG
