#!/bin/bash
source oamenv

echo "OFF" > $STATUS_FILE
echo "quit" > $FIFO_FILE
echo "Stop OAMRadioManager"
