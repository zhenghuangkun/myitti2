#!/bin/bash
source oamenv

if [ $# -ne 2 ];
then
    echo "sudo ./powerparam.sh [lanID] [targetPower]"
    echo "    lanID:{sw_id[1,4]*10+dp_id[1,8]}"
    echo "    targetPower:[0, 25]"
    exit
fi

echo "powerparam $1 $2" > $FIFO_FILE
sleep 1
cat $RESULT_LOG
