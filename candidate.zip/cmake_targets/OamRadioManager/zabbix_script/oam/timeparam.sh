#!/bin/bash
source oamenv

if [ $# -ne 1 ];
then
    echo "sudo ./timeparam.sh [localTimeZone]"
    echo "    bandwidth:[-12, +14]"
    exit
fi

echo "timeparam $1" > $FIFO_FILE
sleep 1
cat $RESULT_LOG
