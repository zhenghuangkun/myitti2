#!/bin/bash

SUDO="sudo -S"

pid1=$(top -n 1 -b -d 1 -Hp `pgrep lte-softmod` | grep rte_mp_handle | awk '{print $1}')
echo "traffic" | $SUDO taskset -cp 9-10 ${pid1}

pid2=$(top -n 1 -b -d 1 -Hp `pgrep lte-softmod` | grep rte_mp_async | awk '{print $1}')
echo "traffic" | $SUDO taskset -cp 9-10 ${pid2}

pid3=$(top -n 1 -b -d 1 -Hp `pgrep lte-softmod` | grep eal-intr-thread | awk '{print $1}')
echo "traffic" | $SUDO taskset -cp 9-10 ${pid3}

pid4=$(top -n 1 -b -d 1 -Hp `pgrep lte-softmod` | grep lcore-slave-15 | awk '{print $1}')
echo "traffic" | $SUDO taskset -cp 13 ${pid4}

