#!/bin/bash
source oamenv

if [ $# -ne 3 ];
then
    echo "sudo ./collectlog.sh [port] [log file] [maxSize]"
    echo "    port:60006"
    echo "    log file:*.zip"
    echo "    maxSize:*.[0, 65535]"
    exit
fi

echo "collectlog $1 $LOG_PATH/$2 $3" > $FIFO_FILE
sleep 1
cat $RESULT_LOG
