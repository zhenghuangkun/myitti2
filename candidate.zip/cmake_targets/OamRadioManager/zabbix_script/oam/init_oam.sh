#!/bin/bash

sudo -E modprobe be 8021q
sleep 4
sudo ifconfig vEth0 up
sleep 4
sudo vconfig add vEth0 11
sleep 4
sudo ifconfig vEth0.11 192.168.196.240
sleep 4
