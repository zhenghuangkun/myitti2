#!/bin/bash
source oamenv

echo Send log from $LOG_PATH to $ZABBIX_SERVER_IP/smbshare/zabbix/log/oam

cd $LOG_PATH
cp /var/log/syslog .
cp /etc/oai/oamsyslog .
sudo zip oam_$(date +%Y%m%d%H%M%S).zip *

sudo rm -rf /tmp/smb
mkdir /tmp/smb
sudo mount -t cifs -o username=$ZABBIX_SERVER_USER_NAME,password=$ZABBIX_SERVER_PASSWORD //$ZABBIX_SERVER_IP/smbshare/zabbix/log/oam /tmp/smb
sudo cp /etc/oai/oam_*.zip /tmp/smb
sudo umount /tmp/smb

