#!/bin/bash
source oamenv

if [ $# -ne 2 ];
then
    echo "sudo ./paparam.sh [lanID] [paStatus]"
    echo "    lanID:{sw_id[1,4]*10+dp_id[1,8]}"
    echo "    paStatus   Tx(LNA)   Rx(LNA)"
    echo "        0       off       off"
    echo "        1       on        on"
    echo "        2       on        off"
    echo "        3       off       on"
    exit
fi

echo "paparam $1 $2" > $FIFO_FILE
sleep 1
cat $RESULT_LOG
