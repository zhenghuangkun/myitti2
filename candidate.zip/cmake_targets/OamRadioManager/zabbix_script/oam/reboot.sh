#!/bin/bash
source oamenv

if [ $# -ne 2 ];
then
    echo "sudo ./reboot.sh [deviceType] [device]"
    echo "    deviceType = 1, means restart CB"
    echo "    deviceType = 2, means restart SW"
    echo "        device = 0 means restart all SW"
    echo "        device = 1 ~ 4 means restart one of SW"
    echo "    deviceType = 3, which means restart pRadio"
    echo "        device = 0 means restart all pRadio of all SW"
    echo "        device = 10/20/30/40 means restart all pRadio under sw1 / sw2 / sw3 / sw4"
    echo "        device = 11 ~ 18 means restart a pRadio under sw1 (same as 2X, 3X, 4X)"
    exit
fi

echo "reboot $1 $2" > $FIFO_FILE
sleep 1
cat $RESULT_LOG
