#!/bin/bash

echo "OFF" > $STATUS_FILE
sudo kill -2 `ps -aux|grep -E "hss|mme|spgw"|awk '{print $2}'`
sleep 1
ps -fe|grep -E "hss|mme|spgw"|grep -v grep
if [ $? -eq 0 ];then
	sudo kill -9 `ps -aux|grep -E "hss|mme|spgw"|awk '{print $2}'`
fi
echo "Stop hss mme spgw"
