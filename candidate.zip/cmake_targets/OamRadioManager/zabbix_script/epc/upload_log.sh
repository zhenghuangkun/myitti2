#!/bin/bash
source epcenv

echo Send log from $LOG_PATH to $ZABBIX_SERVER_IP/smbshare/zabbix/log/epc

cd $LOG_PATH 
cp /var/log/syslog .
cp /usr/local/etc/oai/hss.conf .
cp /usr/local/etc/oai/mme.conf .
cp /usr/local/etc/oai/spgw.conf .
sudo zip epc_$(date +%Y%m%d%H%M%S).zip *

sudo rm -rf /tmp/smb
mkdir /tmp/smb
sudo mount -t cifs -o username=$ZABBIX_SERVER_USER_NAME,password=$ZABBIX_SERVER_PASSWORD //$ZABBIX_SERVER_IP/smbshare/zabbix/log/epc /tmp/smb
sudo cp /tmp/epc/epc_*.zip /tmp/smb
sudo umount /tmp/smb
