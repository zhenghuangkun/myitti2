#!/bin/bash

sudo ./stop.sh
sleep 1
./start.sh
