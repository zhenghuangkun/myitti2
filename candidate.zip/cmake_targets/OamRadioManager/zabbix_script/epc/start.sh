#!/bin/bash
source epcenv

cd $LOG_PATH 
rm -rf *.zip

echo "cd $EPC_WORK_PATH"
cd $EPC_WORK_PATH
echo "nohup sudo -E ./run_hss > $LOG_PATH/hss.log 2>&1 &"
nohup sudo -E ./run_hss > $LOG_PATH/hss.log 2>&1 &
echo "nohup sudo -E ./run_mme > $LOG_PATH/mme.log 2>&1 &"
nohup sudo -E ./run_mme > $LOG_PATH/mme.log 2>&1 &
echo "nohup sudo -E ./run_spgw > $LOG_PATH/spgw.log 2>&1 &"
nohup sudo -E ./run_spgw > $LOG_PATH/spgw.log 2>&1 &
echo "ON" > $STATUS_FILE
