build:
	make clean
	make -f Makefile

run:
	1.Increase zabbix access to syslog permissions, if need work with zabbix:
	setfacl -m u:zabbix:r /var/log/syslog

	2.Modify the path in the OAM work path in the script/oamenv 
	example：bash_path="/home/jftt/work_jftt/lu/candidate/cmake_targets/OamRadioManager"

	3.set OAM vLAN:
	sudo ./init.sh

	4.run process:
	sudo ./start.sh

	5.run API:
	sudo ./cellparam.sh [arfcn] [phyCellId] [subFrameAssignment] [specialSubframePatterns] [bandwidth] [antenna]
	sudo ./collectlog.sh [port] [log file] [maxSize]
	sudo ./paparam.sh [lanID] [paStatus]
	sudo ./powerparam.sh [lanID] [targetPower]
	sudo ./reboot.sh [deviceType] [device]
	sudo ./timeparam.sh [localTimeZone]
	sudo ./upgrade.sh [Port] [packageFile]
	sudo ./debugcmd.sh [cmd] [arg...]

	6.stop process:
	sudo ./start.sh
