#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include "GetLibFunction.h"
#include<pthread.h>
#include <signal.h>

#define CMD_NUM            10
#define CMD_LENGTH         64
#define CMD_BUFFER_SIZE    640
#define LOG_BUFFER_SIZE    1024

#define OAM_IP             "192.168.196.240"
#define OAM_PORT           50005
#define SYS_LOG_FILE       "oamsyslog"
#define FIFO_NAME          "/etc/oai/OAMFIFO"
#define RESULT_LOG_FILE    "result.log"

#define PAPARAM_RESET_ENABLE        1
#define POWER_RESET_ENABLE          1

#define CB_OFFLINE_REBOOT_ENABLE    1
#define CB_WARNING_REBOOT_ENABLE    0
#define SW_OFFLINE_REBOOT_ENABLE    1
#define DEBUGCMD_REBOOT_ENABLE      1
#define CELLPARAM_REBOOT_ENABLE     1
#define ALARM_REBOOT_ENABLE         1
#define TIMEOUT_REBOOT_ENABLE       1
#define TTI_REBOOT_ENABLE           1
#define WATCHDOG_REBOOT_ENABLE      1
#define DELETEIF_REBOOT_ENABLE      1
#define NOT_SYSLOG_REBOOT_ENABLE    (CB_OFFLINE_REBOOT_ENABLE || CB_WARNING_REBOOT_ENABLE || SW_OFFLINE_REBOOT_ENABLE || DEBUGCMD_REBOOT_ENABLE || CELLPARAM_REBOOT_ENABLE || ALARM_REBOOT_ENABLE || TIMEOUT_REBOOT_ENABLE || TTI_REBOOT_ENABLE)
#define SYSLOG_REBOOT_ENABLE        (WATCHDOG_REBOOT_ENABLE || DELETEIF_REBOOT_ENABLE)
#define REBOOT_ENABLE               (NOT_SYSLOG_REBOOT_ENABLE || SYSLOG_REBOOT_ENABLE)

#if WATCHDOG_REBOOT_ENABLE || DELETEIF_REBOOT_ENABLE
#define SYSLOG_FILE        "/var/log/syslog"
#define SYSLOG1_FILE       "/var/log/syslog.1"
#endif

#if REBOOT_ENABLE
typedef struct{
    char *name;
    char *file_name;
    int max_reboot_count;
    int frequency;//min
    int enable_flag;
    int reboot_count;
    int reboot_flag;
    int frequency_count;
    int time_count;
    int timer_flag;
} Monitor_Info_t;

typedef enum {
    cb_offline_monitor_id = 0,
    cb_warning_monitor_id,
    sw_offline_monitor_id,
    debugcmd_monitor_id,
    cellparam_monitor_id,
    alarm_monitor_id,
    timeout_monitor_id,
    ttidisappear_monitor_id,
    watchdog_monitor_id,
    deleteif_monitor_id,
    monitor_count
}Monitor_Tpye_e;

Monitor_Info_t monitors_info[]={
    {"CB offline", "cb_offline_count.txt", 4, 15, 0, 0, 0, 0, 0, 0},
    {"CB warning", "cb_warning_count.txt", 4, 15, 0, 0, 0, 0, 0, 0},
    {"SW offline", "sw_offline_count.txt", 4, 15, 0, 0, 0, 0, 0, 0},
    {"Debug cmd", "debugcmd_count.txt", 4, 15, 0, 0, 0, 0, 0, 1},
    {"Cell param", "cellparam_count.txt", 4, 15, 0, 0, 0, 0, 0, 1},
    {"Alarm", "alarm_count.txt", 4, 15, 0, 0, 0, 0, 0, 1},
    {"CB connect timeout", "timeout_count.txt", 4, 15, 0, 0, 0, 0, 0, 1},
    {"TTI disappear", "ttidisappear_count.txt", 4, 15, 0, 0, 0, 0, 0, 1},
    {"Watchdog", "watchdog_count.txt", 4, 15, 0, 0, 0, 0, 0, 1},
    {"Network", "deleteif_count.txt", 4, 15, 0, 0, 0, 0, 0, 1}
};

#if WATCHDOG_REBOOT_ENABLE
#define WTACHDOG_LIST_COUNT 22
char *watchdog_info_list[WTACHDOG_LIST_COUNT] = {"",
    "lte-softmodem",
    "flush_mem_log",
    "phs_timer",
    "phr_calc",
    "carrier_sense",
    "TASK_ENB_APP",
    "TASK_RRC_ENB",
    "TASK_SCTP",
    "TASK_S1AP",
    "TASK_X2AP",
    "TASK_UDP",
    "TASK_GTPV1_U",
    "ru thread",
    "ru_time_thread",
    "measure main",
    "TASK_MAC_PRESCD",
    "thread_prach",
    "thread_prach_br",
    "rte_mp_handle",
    "rte_mp_async",
    "eal-intr-thread"
};
#endif
#endif

typedef struct eutra_bandentry_s {
  int band;
  int ul_min;
  int ul_max;
  int dl_min;
  int dl_max;
  int N_OFFs_DL;
} eutra_bandentry_t;

static const eutra_bandentry_t eutra_bandtable = {39, 18800, 19200, 18800, 19200, 382500};

Uint32 oam_exit = 0;
Uint32 cb_status = CB_IDLE;
FILE *oam_syslog_fp = NULL;
pthread_mutex_t oam_sys_log_mtx = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
  Uint8 pradio_lanID[32];
  Uint8 pradio_sxgp[32];
  Uint8 pradio_status[4][8];
  Uint8 pradio_power[4][8];
} Pradio_Info_t;

int eNB_pid = 0;
Uint8 pradio_conf_num = 0;
Uint8 pradio_start_flag[4][8] = {0};
Uint8 pradio_num = 0;
CB_INFO cb_info = {0};
char log_path[30] = {0};
Uint8 rf_status = 0;

Pradio_Info_t  pradio_info = {0};
Uint8 last_pradio_num = 0;
Uint8 pradio_failsafe_num = 0;
Uint8 pradio_failsafe_maxnum = 0;
#ifdef SW_OFFLINE_REBOOT_ENABLE
Uint8 sw_offline_flag[4] = {0};
#endif

Int32 fifo;

int oam_syslog_open()
{
    char log_name[1024] = {0};
    sprintf(log_name, "%s/%s", log_path, SYS_LOG_FILE);
    if(access("/etc/oai", 0) == -1){
        mkdir("/etc/oai", 0700);
    }
    if(access(log_path, 0) == -1){
        mkdir(log_path, 0700);
    }
    if(-1 == (access(log_name,F_OK))){
        creat(log_name, 0644);
    }else{
        chmod(log_name, 0644);
    }
    oam_syslog_fp = fopen(log_name, "a+");
    if(NULL == oam_syslog_fp)
    {
        printf("open oam syslog error\n");
        return -1;
    }
    return 0;
}

void oam_syslog_close()
{
    fclose(oam_syslog_fp);
}

void oam_syslog(char *format, ...)
{
    char buffer[LOG_BUFFER_SIZE] = {0};
    va_list args;
    time_t timep;
    struct tm *p;

    va_start(args, format);

    time(&timep);
    p=localtime(&timep);
    pthread_mutex_lock(&oam_sys_log_mtx);
    vsnprintf(buffer, sizeof(buffer), format, args);
    fprintf(oam_syslog_fp, "[%d-%02d-%02d %02d:%02d:%02d] OAMRadioManager %s",
           1900+p->tm_year,
           p->tm_mon+1,
           p->tm_mday,
           p->tm_hour,
           p->tm_min,
           p->tm_sec,
           buffer);
    fflush(oam_syslog_fp);
    pthread_mutex_unlock(&oam_sys_log_mtx);

    va_end(args);
}


void oam_fifo_close(Int32 fifo)
{
    close(fifo);
    unlink(FIFO_NAME);
}


void exit_fun(){
    oam_exit = 1;
    cb_status = CB_IDLE;
    pthread_mutex_destroy(&oam_sys_log_mtx);
    oam_syslog("========OAM Radio Manager Exit========\n");
    oam_fifo_close(fifo);
    oam_syslog_close();
    exit(0);
}

int to_earfcn(int dl_carrier_freq) {
  int dl_CarrierFreq_by_100k = dl_carrier_freq / 100000;
  int bw = 25*180;
  int bw_by_100 = bw / 100;
  int eutra_bandP = 39;
  if(dl_CarrierFreq_by_100k < eutra_bandtable.dl_min) {
    printf("Band %d, bw %u : DL carrier frequency %u Hz < %u\n", eutra_bandP, bw, dl_carrier_freq, eutra_bandtable.dl_min);
    return -1;
  }
  if(dl_CarrierFreq_by_100k > (eutra_bandtable.dl_max - bw_by_100)) {
    printf("Band %d, bw %u: DL carrier frequency %u Hz > %d\n", eutra_bandP, bw, dl_carrier_freq, eutra_bandtable.dl_max - bw_by_100);
    return -1;
  }
  return (dl_CarrierFreq_by_100k - eutra_bandtable.dl_min + (eutra_bandtable.N_OFFs_DL / 10));
}

void get_conf(void){
  char conf_file[50]="OAMPradioManager.conf";
  char temp[20]={0};
  char StrLine[1024];
  char *str_p = NULL;
  int len = 0;
  FILE* fp = fopen(conf_file, "rb");
  if(fp==NULL){
   oam_syslog("open file %s error\n",conf_file);
   return;
  }
  memset (&cb_info, 0, sizeof(cb_info));
  while (!feof(fp))
  {
    fgets(StrLine,1024,fp);
    if(strstr(StrLine,"das_sw_")){
      for(int i=0; i<4; i++){
        snprintf(temp,20,"das_sw_%d",i+1);
        if(strncmp(StrLine,temp,strlen(temp)) == 0){
          str_p = strchr(StrLine,'"');
          if(strncmp(str_p+1,"ENABLE",strlen("ENABLE")-1) == 0){
            cb_info.sw_flag[i] = 1;
          }else if(strncmp(str_p+1,"DISABLE",strlen("DISABLE")) == 0){
            cb_info.sw_flag[i] =0;
          }
          break;
        }
      }
    }else if(strstr(StrLine,"das_pradio_")){
      for(int i=0; i<4; i++){
        snprintf(temp,20,"das_pradio_%dx",i+1);
        if(strncmp(StrLine,temp,strlen(temp)) == 0){
          str_p = strstr(StrLine,"0x");
          for(int j = 0;j < 8;j++){
            if(strncmp(str_p+j+2,"1",1) == 0){
              cb_info.pradio_flag[i][7-j] = 1;
            }else if(strncmp(str_p+j+2,"0",1) == 0){
              cb_info.pradio_flag[i][7-j] = 0;
            }
          }
          break;
        }
      }
    }else if(strncmp(StrLine,"das_powerparam",strlen("das_powerparam")) == 0){
      str_p = strchr(StrLine,'=');
      cb_info.power_param = atoi(str_p+1);
    }else if(strncmp(StrLine,"log_path",strlen("log_path")) == 0){
      str_p = strchr(StrLine,'=');
      len = 0;
      do{
        len++;
      }while(str_p[len]!='"');
      str_p = &(str_p[len+1]);
      len = 0;
      do{
        log_path[len] = str_p[len];
        len++;
      }while(str_p[len]!='"');
      log_path[len] = '\0';
    }else if(strncmp(StrLine,"pradio_failsafe_maxnum",strlen("pradio_failsafe_maxnum")) == 0){
      str_p = strchr(StrLine,'=');
      pradio_failsafe_maxnum = atoi(str_p+1);
    }else if(strncmp(StrLine,"rf_status",strlen("rf_status")) == 0){
      str_p = strchr(StrLine,'"');
      if(strncmp(str_p+1,"ENABLE",strlen("ENABLE")-1) == 0){
        rf_status = 1;
      }else if(strncmp(str_p+1,"DISABLE",strlen("DISABLE")) == 0){
        rf_status =0;
      }
    }else if(strncmp(StrLine,"downlink_frequency",strlen("downlink_frequency")) == 0){
      str_p = strchr(StrLine,'=');
      cb_info.dl_carrier_freq = atoi(str_p+1);
      if(cb_info.dl_carrier_freq!=1891000000 && cb_info.dl_carrier_freq!=1899100000 && cb_info.dl_carrier_freq!=1914100000)
      {
        printf("Error config: downlink_frequency(%d): {1891000000(F1), 1899100000(F0), 1914100000(F2)}", cb_info.dl_carrier_freq);
        fclose(fp);
        exit(1);
      }
      cb_info.cell_param.arfcn = to_earfcn(cb_info.dl_carrier_freq);
      cb_info.cell_param.phyCellId = 100;
      cb_info.cell_param.subFrameAssignment = 1;
      cb_info.cell_param.specialSubframePatterns = 0;
      cb_info.cell_param.bandwidth = 25;
      cb_info.cell_param.antenna = 2;
    }
  }
  fclose(fp);
}
void show_conf(void){
  oam_syslog("log_path: %s\n", log_path);
  oam_syslog("power_param: %d\n", cb_info.power_param);
  oam_syslog("rf_status: %s\n", rf_status?"rf on":"rf off");
  for(int i = 0;i <4;i++){
    oam_syslog("config :sw[%d] %d pradio %d %d %d %d %d %d %d %d\n",i,cb_info.sw_flag[i],
               cb_info.pradio_flag[i][0],cb_info.pradio_flag[i][1],cb_info.pradio_flag[i][2],cb_info.pradio_flag[i][3],
               cb_info.pradio_flag[i][4],cb_info.pradio_flag[i][5],cb_info.pradio_flag[i][6],cb_info.pradio_flag[i][7]);
    if(cb_info.sw_flag[i] == 1){
      for(int j = 0;j < 8;j++){
        if(cb_info.pradio_flag[i][j] == 1){
          pradio_info.pradio_lanID[pradio_conf_num] = (i+1)*10+j+1;
          pradio_info.pradio_sxgp[pradio_conf_num] = 2;
          pradio_conf_num++;
        }
      }
    }
  }
  if(pradio_conf_num == 0){
    oam_syslog("read config: pradio num 0\n");
  }
  oam_syslog("dl_carrier_freq: %d\n", cb_info.dl_carrier_freq);
  oam_syslog("arfcn: %d\n", cb_info.cell_param.arfcn);
  oam_syslog("phyCellId: %d\n", cb_info.cell_param.phyCellId);
  oam_syslog("subFrameAssignment: %d\n", cb_info.cell_param.subFrameAssignment);
  oam_syslog("specialSubframePatterns: %d\n", cb_info.cell_param.specialSubframePatterns);
  oam_syslog("bandwidth: %d\n", cb_info.cell_param.bandwidth);
  oam_syslog("antenna: %d\n", cb_info.cell_param.antenna);
}

Int8 onepradioset(Uint32 lanID,Uint32 mode);
//Int8 pradioset(Uint8 mode){
Int8 pradioset(Uint32 mode){
  for(Uint8 i = 0;i < pradio_conf_num;i++){
      onepradioset(pradio_info.pradio_lanID[i], mode);
  }
  return 0;
}


//powweParam set
Int8 powerparamset(Uint32 power){
  Uint32 ret;
  S_PowerParam powerParam;
  Int8 i, j=0;
  for(i = 0;i < pradio_conf_num;i++){
    if(pradio_info.pradio_lanID[i] != 0){
      powerParam.lanID = pradio_info.pradio_lanID[i];;
      powerParam.targetPower = power;
#if POWER_RESET_ENABLE
      for(j=0; j<3;j++)
#endif
      {
        ret = call_C_ConfigCBParam(BMCP_POWER_PARAM,
                                  (Uint8*) &powerParam, sizeof(powerParam));
        oam_syslog("Config powerParam, result[%s] lanID[%u] targetPower[%u].\n", get_return_result(ret),
                   powerParam.lanID, powerParam.targetPower);

#if POWER_RESET_ENABLE
        if(ret)
        {
          pradio_info.pradio_power[powerParam.lanID/10 - 1][powerParam.lanID%10 - 1] = powerParam.targetPower;
          break;
        }
        else
        {
          oam_syslog("Config powerParam failed %d times\n", j+1);
          if(2==j)
          {
            oam_syslog("Config powerParam PRadio[%d] set powerParam fail: %d -> %d. Pradio offline\n",
                      powerParam.lanID,pradio_info.pradio_power[powerParam.lanID/10 - 1][powerParam.lanID%10 - 1],powerParam.targetPower);
            for(j = 0;j<pradio_conf_num;j++)
            {
              if(powerParam.lanID == pradio_info.pradio_lanID[j])
              {
                pradio_info.pradio_lanID[j] = 0;
                pradio_info.pradio_sxgp[j] = 0;
                pradio_info.pradio_status[powerParam.lanID/10 - 1][powerParam.lanID%10 - 1] = 0;
                break;
              }
            }
            break;
          }
        }
#endif
      }
    }
  }
  return 0;
}
//One pradio set mode
Int8 onepradioset(Uint32 lanID,Uint32 mode){
  Uint32 ret;
  S_PAParam PAParam;
  PAParam.lanID = lanID;
  PAParam.paStatus = mode;
  Int8 j=0;
#if PAPARAM_RESET_ENABLE
  for(j=0; j<3; j++)
#endif
  {
      ret = call_C_ConfigCBParam(BMCP_PA_PARAM,
                                 (Uint8*) &PAParam, sizeof(PAParam));
      oam_syslog("Config PAParam, result[%s] lanID[%d] paStatus[%d].\n", get_return_result(ret),
                      PAParam.lanID, PAParam.paStatus);
      if(ret)
      {
          pradio_info.pradio_status[lanID/10 - 1][lanID%10 - 1] = PAParam.paStatus;
          if(0 == PAParam.paStatus)
          {
            oam_syslog("PRadio[%d] power amplifier TX/RX turn off.\n", PAParam.lanID);
          }
          else if(1 == PAParam.paStatus)
          {
            oam_syslog("PRadio[%d] power amplifier TX/RX turn on.\n", PAParam.lanID);
          }
          else if(2 == PAParam.paStatus)
          {
            oam_syslog("PRadio[%d] power amplifier TX turn on  RX turn off.\n", PAParam.lanID);
          }
          else if(3 == PAParam.paStatus)
          {
             oam_syslog("PRadio[%d] power amplifier TX turn off  RX turn on.\n", PAParam.lanID);
          }
          sleep(0.5);
          return 0;
      }
      else
      {
          oam_syslog("Config PAParam[%d] failed %d times\n", lanID, j+1);
      }
  }
#if PAPARAM_RESET_ENABLE
  oam_syslog("Config PAParam PRadio[%d] set paparam fail: %d -> %d. Pradio offline\n",
              PAParam.lanID,pradio_info.pradio_status[PAParam.lanID/10 - 1][PAParam.lanID%10 - 1],PAParam.paStatus);
  for(j = 0;j<pradio_conf_num;j++){
    if(PAParam.lanID == pradio_info.pradio_lanID[j]){
      pradio_info.pradio_lanID[j] = 0;
      pradio_info.pradio_sxgp[j] = 0;
      pradio_info.pradio_status[PAParam.lanID/10 - 1][PAParam.lanID%10 - 1] = 0;
      break;
    }
  }
  if(j == pradio_conf_num ){
      oam_syslog("Config PAParam PRadio[%d] is not in pradio list\n",PAParam.lanID);
  }
  return -1;
#else
  return 0;
#endif
}

int my_system(const char *cmd)
{
    int result = 0;
    char buf[1024] = {0};
    FILE *fp = NULL;

    if( (fp = popen(cmd, "r")) == NULL ) {
      oam_syslog("popen error!\n");
      return -1;
    }

    while (fgets(buf, sizeof(buf), fp)) {
        //strcat(result, buf);
        result = atoi(buf);
    }

    pclose(fp);
    return result;
}

//============================== reboot functions =============================
#if REBOOT_ENABLE
void setRebootCnt(Monitor_Tpye_e monitor_type, int count)
{
    FILE *fp = NULL;
    char log_name[1024];

    sprintf(log_name, "%s/%s", log_path, monitors_info[monitor_type].file_name);
    fp = fopen(log_name, "w+");
    fprintf(fp,"%d", count);
    fclose(fp);
}

void init_monitor_info()
{
    FILE *fp = NULL;
    char log_name[1024];

#if CB_OFFLINE_REBOOT_ENABLE
    monitors_info[cb_offline_monitor_id].enable_flag = 1;
#else
    monitors_info[cb_offline_monitor_id].enable_flag = 0;
#endif

#if CB_WARNING_REBOOT_ENABLE
    monitors_info[cb_warning_monitor_id].enable_flag = 1;
#else
    monitors_info[cb_warning_monitor_id].enable_flag = 0;
#endif

#if SW_OFFLINE_REBOOT_ENABLE
    monitors_info[sw_offline_monitor_id].enable_flag = 1;
#else
    monitors_info[sw_offline_monitor_id].enable_flag = 0;
#endif

#if DEBUGCMD_REBOOT_ENABLE
    monitors_info[debugcmd_monitor_id].enable_flag = 1;
#else
    monitors_info[debugcmd_monitor_id].enable_flag = 0;
#endif

#if CELLPARAM_REBOOT_ENABLE
    monitors_info[cellparam_monitor_id].enable_flag = 1;
#else
    monitors_info[cellparam_monitor_id].enable_flag = 0;
#endif

#if ALARM_REBOOT_ENABLE
    monitors_info[alarm_monitor_id].enable_flag = 1;
#else
    monitors_info[alarm_monitor_id].enable_flag = 0;
#endif

#if TIMEOUT_REBOOT_ENABLE
    monitors_info[timeout_monitor_id].enable_flag = 1;
#else
    monitors_info[timeout_monitor_id].enable_flag = 0;
#endif

#if WATCHDOG_REBOOT_ENABLE
    monitors_info[watchdog_monitor_id].enable_flag = 1;
#else
    monitors_info[watchdog_monitor_id].enable_flag = 0;
#endif

#if DELETEIF_REBOOT_ENABLE
    monitors_info[deleteif_monitor_id].enable_flag = 1;
#else
    monitors_info[deleteif_monitor_id].enable_flag = 0;
#endif

#if TTI_REBOOT_ENABLE
    monitors_info[ttidisappear_monitor_id].enable_flag = 1;
#else
    monitors_info[ttidisappear_monitor_id].enable_flag = 0;
#endif

    for(int i=0; i<monitor_count; i++)
    {
        if(monitors_info[i].enable_flag)
        {
            sprintf(log_name, "%s/%s", log_path, monitors_info[i].file_name);
            fp = fopen(log_name, "r");
            if(fp == NULL){
                setRebootCnt(i, 0);
                monitors_info[i].reboot_count = 0;
            } else {
                fscanf(fp,"%d",&(monitors_info[i].reboot_count));
                fclose(fp);
            }
            monitors_info[i].reboot_flag = 0;
            monitors_info[i].frequency_count = 0;
            monitors_info[i].time_count=0;
            monitors_info[i].timer_flag=1;
        }
    }
    monitors_info[cb_offline_monitor_id].timer_flag = 0;
    monitors_info[cb_warning_monitor_id].timer_flag = 0;
    monitors_info[sw_offline_monitor_id].timer_flag = 0;
}

void stopAutoRecoverService(){
    // stop the auto recover service
    oam_syslog("ready to stop the auto recover service\n");
    system("logger -it OAM 'ready to stop the auto recover service'");
    cb_status = CB_IDLE;
    int ret3 = system ("sudo systemctl stop bbu");
    if(ret3 == -1){
        oam_syslog("bbu.service stop failed\n");
    }
    oam_syslog("========OAM Radio Manager Exit========\n");
    int ret1 = system ("sudo systemctl stop oam");
    if(ret1 == -1){
        oam_syslog("oam.service stop failed\n");
    }
}
#endif

#if NOT_SYSLOG_REBOOT_ENABLE
static void check_monitors()
{
    char logger_buffer[1024];
    char status_name[100];
    union sigval mysigval;
    int i = 0;

    //check reboot
    for(i=0; i<monitor_count; i++)
    {
        if(monitors_info[i].enable_flag)
        {
            //maybe can reset error.
            if(0 == monitors_info[i].timer_flag && 1 == monitors_info[i].reboot_flag)
            {
                //reset timer
                monitors_info[i].time_count = 0;
                monitors_info[i].frequency_count = 0;
                monitors_info[i].timer_flag = 1;
            }

            //reset error.
            if(0 == monitors_info[i].reboot_flag && (i==cb_offline_monitor_id || i==cb_warning_monitor_id || i==sw_offline_monitor_id))
            {
                monitors_info[i].timer_flag = 0;
            }
            //timer count ++
            monitors_info[i].time_count = monitors_info[i].time_count % 60 + 1;
            if(monitors_info[i].time_count < 60)
            {
                //this is not a check time.
                continue;
            }

            //check reboot_flag
            monitors_info[i].frequency_count = monitors_info[i].frequency_count % monitors_info[i].frequency + 1;
#if TIMEOUT_REBOOT_ENABLE
            if(cb_status == CB_IDLE && i == timeout_monitor_id && monitors_info[i].frequency_count == monitors_info[i].frequency)
            {
                monitors_info[timeout_monitor_id].reboot_flag = 1;
            }
#endif

            if (monitors_info[i].timer_flag && monitors_info[i].reboot_flag){
                monitors_info[i].reboot_count++;
#if WATCHDOG_REBOOT_ENABLE
                if(i == watchdog_monitor_id){
                    sprintf(status_name,"%s[%s]", monitors_info[i].name, watchdog_info_list[monitors_info[i].reboot_flag]);
                }
                else
#endif
                {
                    sprintf(status_name,"%s", monitors_info[i].name);
                }
                oam_syslog("%s error occurs\n", status_name);
                oam_syslog("%s reboot count is %d\n", status_name, monitors_info[i].reboot_count);
                if(monitors_info[i].reboot_count > monitors_info[i].max_reboot_count){
                    sprintf(logger_buffer, "logger -it OAM '%s error occurs, eNB exit'", status_name);
                    system(logger_buffer);
                    stopAutoRecoverService();
                }else{
                    if(i == alarm_monitor_id){
                        //SW reboot
                        Uint32 ret2 =call_C_RebootDevice(2,0);
                        oam_syslog("Reboot SW result[%s] deviceType[%d] device[%d]\n",get_return_result(ret2), 2, 0);
                        //CB reboot
                        Uint32 ret1 = call_C_RebootDevice(1, 0);
                        oam_syslog("Reboot CB result[%s] deviceType[%d] device[%d]\n",get_return_result(ret1), 1, 0);
                    }

                    setRebootCnt(i, monitors_info[i].reboot_count);
                    //send to eNB ,eNB exit
                    mysigval.sival_int = SIGNAL_ENB_EXIT;
                    sigqueue(eNB_pid,SIGUSR1,mysigval);
                    oam_syslog("OAM send SIGUSR1 to ENB pid %d, enb exit\n", eNB_pid);
                    sprintf(logger_buffer, "logger -it OAM '%s error occurs, eNB exit'", status_name);
                    system(logger_buffer);
                    //OAM exit
                    exit_fun();
                }
            } else if(monitors_info[i].frequency_count == monitors_info[i].frequency && 0 != monitors_info[i].reboot_count) {
                monitors_info[i].reboot_count = 0;
                setRebootCnt(i, monitors_info[i].reboot_count);
            }
        }
    }
}

static void *monitor_thread(void* param){
    while(!oam_exit){
        sleep(1); // sleep 60s and then check monitors
        check_monitors();
    }
    return NULL;
}

#endif

#if SYSLOG_REBOOT_ENABLE
int get_file_len(char filename[]){
    FILE *fp = NULL;
    long total_len = 0;
    fp = fopen(filename, "rb");
    if (fp == NULL){
        printf("open syslog file failed\n");
        return -1;
    }
    fseek(fp,0,SEEK_END);
    total_len = ftell(fp);
    fclose(fp);
    return total_len;
}

void check_syslog_reboot(char filename[],long start_len){
    FILE *fp = NULL;
    long end_len = 0;
    int i = 1;
    fp = fopen(filename, "rb");
    if (fp == NULL){
        printf("open syslog failed\n");
    }
    fseek(fp,0,SEEK_END);
    end_len = ftell(fp);
    char buff[end_len-start_len];
    fseek(fp,start_len,SEEK_SET);
    fread(buff,1,end_len-start_len+1,fp);
#if WATCHDOG_REBOOT_ENABLE
    if (strstr(buff,"watchdog")){
        for(i=1; i<WTACHDOG_LIST_COUNT; i++){
            if(strstr(buff,watchdog_info_list[i])){
                monitors_info[watchdog_monitor_id].reboot_flag = i;
                break;
            }
        }
    }
#endif
#if DELETEIF_REBOOT_ENABLE
    if (strstr(buff,"Deleting interface")){
        monitors_info[deleteif_monitor_id].reboot_flag = 1;
    }
#endif
    fclose(fp);
}

static void *monitor_syslog_thread(void* param){
    long prev_total_len = 0;
    long total_len = 0;

    prev_total_len = get_file_len(SYSLOG_FILE);
    while(!oam_exit){
        if (prev_total_len == -1) break;
        // sleep 60s and then check syslog status
        sleep(1);
        total_len = get_file_len(SYSLOG_FILE);
        //check if syslog splited
        if (total_len > prev_total_len){
            // syslog doesn't split
            check_syslog_reboot(SYSLOG_FILE,prev_total_len);
        }else if (total_len < prev_total_len){
            //syslog splited
            check_syslog_reboot(SYSLOG1_FILE,prev_total_len);
            check_syslog_reboot(SYSLOG_FILE,0);
        }
        prev_total_len = total_len;
    }
    return NULL;
}
#endif

void CBConnectHandler(void)
{
    cb_status = CB_CONNECT;
    oam_syslog("Callback Result: Now cb connect.\n");
#if TIMEOUT_REBOOT_ENABLE
    // reset timeout count and flag
    monitors_info[timeout_monitor_id].reboot_count = 0;
    setRebootCnt(timeout_monitor_id, monitors_info[timeout_monitor_id].reboot_count);
#endif

#if CB_OFFLINE_REBOOT_ENABLE
    monitors_info[cb_offline_monitor_id].reboot_flag = 0;
#endif
}

void CBOfflineHandler(void)
{
    cb_status = CB_IDLE;
    oam_syslog("Callback Result: Now cb offline.\n");
#if CB_OFFLINE_REBOOT_ENABLE
    monitors_info[cb_offline_monitor_id].reboot_flag = 1;
#endif
}

static void *signal_thread(void* param){
  while(pradio_num != pradio_conf_num){
    sleep(1);
  }
  sleep(3);
  //pradio 0
  Int8 ret = pradioset(0);
  if(ret == 0){
    //powerparamset();
    //tti close
    char debug_cmd[CMD_NUM*CMD_LENGTH] = {0};
    Uint32 offset = 0;
    char* result;
    offset += sprintf(debug_cmd+offset, "set PackageParam: PackageType = 0;");
    result = call_C_ConfigDebugCmd(debug_cmd);
    oam_syslog("Debugcmd cmd[%s] result:%s\n", debug_cmd, result);
    if(strcmp(result, "success") != 0) {
      oam_syslog("Debugcmd cmd[%s] failure\n",debug_cmd);
#if DEBUGCMD_REBOOT_ENABLE
      monitors_info[debugcmd_monitor_id].reboot_flag = 1;
#endif
      return NULL;
    }

    //cellparam TDD
    cb_info.cell_param.subFrameAssignment = 1;
    cb_info.cell_param.specialSubframePatterns = 0;
    int ret = call_C_ConfigCBParam(BMCP_CELL_PARAM,
          (Uint8*) &cb_info.cell_param, sizeof(cb_info.cell_param));
    oam_syslog("Config cellParam, result[%s] arfcn[%u] phyCellId[%u] "
          "subFrameAssignment[%u] specialSubframePatterns[%u] "
          "bandwidth[%u] antenna[%u].\n", get_return_result(ret),
                      cb_info.cell_param.arfcn, cb_info.cell_param.phyCellId,
                      cb_info.cell_param.subFrameAssignment,
                      cb_info.cell_param.specialSubframePatterns, cb_info.cell_param.bandwidth,
                      cb_info.cell_param.antenna);
    if(!ret) {
#if CELLPARAM_REBOOT_ENABLE
      monitors_info[cellparam_monitor_id].reboot_flag = 1;
#endif
      return NULL;
    }
    //power
    sleep(1);
    powerparamset(21);
    powerparamset(cb_info.power_param);
    sleep(1);

    //send to enb
    union sigval mysigval;
    mysigval.sival_int= SIGNAL_OAM_STRAT_IND;
    sigqueue(eNB_pid,SIGUSR1,mysigval);
    oam_syslog("OAM send SIGUSR1 to OAM pid %d, OAM start\n",eNB_pid);
  }else{
    oam_syslog("signal_thread  pradioset failure %d\n",ret);
  }
  return NULL;
}

void CBReportParamHandler(Uint32 dataID, Uint8* pData, Uint32 len)
{
    if (BMCP_CB_DEVICE_INFO == dataID) {
        S_CBDeviceInfo cbDeviceInfo;
        if (sizeof(S_CBDeviceInfo) != len) {
           oam_syslog("Callback Result: Check data[%u] len[%u] not equal struct len[%lu].\n",
                  dataID, len, sizeof(S_CBDeviceInfo));
           return;
        }
        memcpy(&cbDeviceInfo, pData, len);
        if (1 == cbDeviceInfo.lanID) {
          oam_syslog("Callback Result: Recieve CB device info"
                      "  lanID:%d"
                      "  modelName:%s"
                      "  serialNumber:%s"
                      "  hardwareVersion:%s"
                      "  softwareVersion:%s"
                      "  status:%d (%s)\n",
              cbDeviceInfo.lanID, cbDeviceInfo.modelName,
              cbDeviceInfo.serialNumber, cbDeviceInfo.hardwareVersion,
              cbDeviceInfo.softwareVersion, cbDeviceInfo.status, get_status_name(cbDeviceInfo.status));
#if CB_OFFLINE_REBOOT_ENABLE
          if(Offline == cbDeviceInfo.status)
          {
              monitors_info[cb_offline_monitor_id].reboot_flag = 1;
          }
          else
          {
              monitors_info[cb_offline_monitor_id].reboot_flag = 0;
          }
#endif
#if CB_WARNING_REBOOT_ENABLE
          if(Warning == cbDeviceInfo.status)
          {
              monitors_info[cb_warning_monitor_id].reboot_flag = 1;
          }
          else
          {
              monitors_info[cb_warning_monitor_id].reboot_flag = 0;
          }
#endif
        }
        else {
          oam_syslog("Callback Result: Recieve CB device info with error lanID(%d).\n", cbDeviceInfo.lanID);
        }
    } else if (BMCP_SW_DEVICE_INFO == dataID) {
        S_SWDeviceInfo swDeviceInfo;
        if (sizeof(S_SWDeviceInfo) != len) {
           oam_syslog("Callback Result: Check data[%u] len[%u] not equal struct len[%lu].\n",
                  dataID, len, sizeof(S_SWDeviceInfo));
           return;
        }
        memcpy(&swDeviceInfo, pData, len);
        if (1 <= swDeviceInfo.lanID && swDeviceInfo.lanID <= 4) {
          oam_syslog("Callback Result: Recieve sw device info"
              "  lanID:%d"
              "  modelName:%s"
              "  serialNumber:%s"
              "  hardwareVersion:%s"
              "  softwareVersion:%s"
              "  status:%d (%s)\n",
              swDeviceInfo.lanID, swDeviceInfo.modelName,
              swDeviceInfo.serialNumber, swDeviceInfo.hardwareVersion,
              swDeviceInfo.softwareVersion, swDeviceInfo.status, get_status_name(swDeviceInfo.status));
#if SW_OFFLINE_REBOOT_ENABLE
          if (Offline == swDeviceInfo.status && cb_info.sw_flag[swDeviceInfo.lanID-1]) {
            sw_offline_flag[swDeviceInfo.lanID-1] = 1;
          } else {
            sw_offline_flag[swDeviceInfo.lanID-1] = 0;
          }
          if (sw_offline_flag[0] || sw_offline_flag[1] || sw_offline_flag[2] || sw_offline_flag[3]) {
            monitors_info[sw_offline_monitor_id].reboot_flag = 1;
          } else {
            monitors_info[sw_offline_monitor_id].reboot_flag = 0;
          }
#endif
        }
        else {
          oam_syslog("Callback Result: Recieve SW device info with error lanID(%d).\n", swDeviceInfo.lanID);
        }
    } else if (BMCP_DP_DEVICE_INFO == dataID) {
        S_DPDeviceInfo dpDeviceInfo;
        if (sizeof(S_DPDeviceInfo) != len) {
           oam_syslog("Check data[%u] len[%u] not equal struct len[%lu].\n",
                  dataID, len, sizeof(S_DPDeviceInfo));
           return;
        }
        memcpy(&dpDeviceInfo, pData, len);
        if (1 <= dpDeviceInfo.lanID/10 && dpDeviceInfo.lanID/10 <= 4 && 1 <= dpDeviceInfo.lanID%10 && dpDeviceInfo.lanID%10 <=8) {
          oam_syslog("Callback Result: Recieve pRadio device info"
              "  lanID:%d"
              "  modelName:%s"
              "  serialNumber:%s"
              "  hardwareVersion:%s"
              "  softwareVersion:%s"
              "  status:%d (%s)\n",
              dpDeviceInfo.lanID, dpDeviceInfo.modelName,
              dpDeviceInfo.serialNumber, dpDeviceInfo.hardwareVersion,
              dpDeviceInfo.softwareVersion, dpDeviceInfo.status, get_status_name(dpDeviceInfo.status));
          if(dpDeviceInfo.status == 1){
            for(Uint8 i = 0;i < pradio_conf_num;i++){
              if(dpDeviceInfo.lanID ==  pradio_info.pradio_lanID[i]){
                if(pradio_start_flag[dpDeviceInfo.lanID/10-1][dpDeviceInfo.lanID%10-1] == 0){
                  pradio_start_flag[dpDeviceInfo.lanID/10-1][dpDeviceInfo.lanID%10-1] = 1;
                  pradio_num++;
                }
                break;
              }
            }
          }
        }
        else {
          oam_syslog("Callback Result: Recieve pRadio device info with error lanID(%d).\n", dpDeviceInfo.lanID);
        }
    } else if (BMCP_ALARM_PARAM == dataID) {
        S_AlarmParam alarmParam;
        if (sizeof(S_AlarmParam) != len) {
           oam_syslog("Callback Result: Check data[%u] len[%u] not equal struct len[%lu].\n",
                  dataID, len, sizeof(S_AlarmParam));
           return;
        }
        memcpy(&alarmParam, pData, len);
        if (CB_OpticalSyncAbnorml <= alarmParam.alarmID && alarmParam.alarmID <= SW_pRadio_FirmwareUpgradeFailure) {
              oam_syslog("Callback Result: Recieve alarmParam"
              "  alarmID:%d (%s)"
              "  alarmStatus:%d"
              "  alarmCause:%s\n",
              alarmParam.alarmID, get_alarm_name(alarmParam.alarmID),
              alarmParam.alarmStatus,
              alarmParam.alarmCause);
#if ALARM_REBOOT_ENABLE
          if(alarmParam.alarmID == CB_OpticalSyncAbnorml
             ||alarmParam.alarmID == CP_Optical_Lost
             ||alarmParam.alarmID == CB_FirmwareUpgradeFailure
             ||alarmParam.alarmID == SW_OpticalMainSyncAbnorml
             ||alarmParam.alarmID == SW_OpticalAccessorySyncAbnormal
             ||alarmParam.alarmID == SW_FirmwareUpgradeFailure){
              if(alarmParam.alarmStatus == 1){
                monitors_info[alarm_monitor_id].reboot_flag = 1;
              }
          }
#endif
      }
        else {
          oam_syslog("Callback Result: Recieve alarmParam info with error alarmID(%d).\n", alarmParam.alarmID);
        }
     }else if (BMCP_OPTICAL_PARAM == dataID) {
            S_CBOptInfoParam cbOptInfoParam;
            if (sizeof(S_CBOptInfoParam) != len) {
            oam_syslog("Callback Result: Check data[%u] len[%u] not equal struct len[%lu].\n",
            dataID, len, sizeof(S_CBOptInfoParam));
            return;
            }
            memcpy(&cbOptInfoParam, pData, len);
            oam_syslog("Callback Result: Recieve cb opt info param"
            " OpticalPort:%d"
            " SFPSerialNumber:%s"
            " SFPManuDate:%s"
            " SFPNotPresentIndicator:%d"
            " SFPType:%s"
            " SFPOpticalWavelength:%d"
            " SFPSupportingDataRate:%d"
            " SFPTxFaultIndicator:%d"
            " SFPLOSIndicator:%d"
            " SFPRxPower:%s"
            " SFPTxPower:%s"
            " SFPTemperature:%d"
            " SFPSupplyVoltage:%s"
            " SFPSupplyCurrent:%d"
            " CPRILinkStatus:%d"
            " SFPTempHighAlarm:%d"
            " SFPTempLowAlarm:%d"
            " SFPTXPowerHighAlarm:%d"
            " SFPTXPowerLowAlarm:%d"
            " SFPRXPowerHighAlarm:%d"
            " SFPRXPowerLowAlarm:%d\n",
            cbOptInfoParam.OpticalPort, cbOptInfoParam.SFPSerialNumber,
            cbOptInfoParam.SFPManuDate, cbOptInfoParam.SFPNotPresentIndicator,
            cbOptInfoParam.SFPType, cbOptInfoParam.SFPOpticalWavelength,
            cbOptInfoParam.SFPSupportingDataRate, cbOptInfoParam.SFPTxFaultIndicator,
            cbOptInfoParam.SFPLOSIndicator, cbOptInfoParam.SFPRxPower,
            cbOptInfoParam.SFPTxPower, cbOptInfoParam.SFPTemperature,
            cbOptInfoParam.SFPSupplyVoltage, cbOptInfoParam.SFPSupplyCurrent,
            cbOptInfoParam.CPRILinkStatus, cbOptInfoParam.SFPTempHighAlarm,
            cbOptInfoParam.SFPTempLowAlarm, cbOptInfoParam.SFPTXPowerHighAlarm,
            cbOptInfoParam.SFPTXPowerLowAlarm, cbOptInfoParam.SFPRXPowerHighAlarm,
            cbOptInfoParam.SFPRXPowerLowAlarm);
    } else {
        oam_syslog("Callback Result: Can not handler data id[%d].\n", dataID);
    }
}


Uint32 split(char *src, const char *separator, char dest[][64])
{
    char *pNext;
    Uint32 count = 0;
    if (src == NULL || strlen(src) == 0)
        return 0;
    if (separator == NULL || strlen(separator) == 0){
        strcpy(dest[0], src);
        count = 1;
        return count;
    }
    if(strstr(src, separator) == NULL){
        strcpy(dest[0], src);
        count = 1;
        return count;
    }
    pNext = (char *)strtok(src, separator);
    while(pNext != NULL) {
        strcpy(dest[count++], pNext);
        pNext = (char *)strtok(NULL, separator);
    }
    return count;
}

int get_uint32(Uint32 *num, char *buf)
{
    int i = 0;
    long data = 0;
    if(num == NULL || buf == NULL)
    {
        return -1;
    }
    while(buf[i]!='\0')
    {
        if(buf[i]>'9'||buf[i]<'0')
        {
            return -1;
        }
        data=data*10+buf[i++]-'0';
        if(data>4294967295)
        {
            return -1;
        }
    }
    *num = data;
    return 0;
}

void Exec_cmd(char cmd[][CMD_LENGTH], Uint32 num, FILE *result_fp)
{
    Uint32 ret;
    if(strcmp("cellparam", cmd[0])==0){
        S_CellParam cellParam;
        if(num != 7){
           fprintf(result_fp, "Illegal number of parameters for cellparam\n");
           return;
        }
        if(0 != get_uint32(&(cellParam.arfcn), cmd[1]))
        {
            fprintf(result_fp, "cellparam arfcn:%s error it should be {0~4294967295}\n", cmd[1]);
            return;
        }
        if(0 != get_uint32(&(cellParam.phyCellId), cmd[2]))
        {
            fprintf(result_fp, "cellparam phyCellId:%s error it should be {0~4294967295}\n", cmd[2]);
            return;
        }
        if(0 != get_uint32(&(cellParam.subFrameAssignment), cmd[3]))
        {
            fprintf(result_fp, "cellparam subFrameAssignment:%s error it should be {0~4294967295}\n", cmd[3]);
            return;
        }
        if(0 != get_uint32(&(cellParam.specialSubframePatterns), cmd[4]))
        {
            fprintf(result_fp, "cellparam specialSubframePatterns:%s error it should be {0~4294967295}\n", cmd[4]);
            return;
        }
        if(0 != get_uint32(&(cellParam.bandwidth), cmd[5]))
        {
            fprintf(result_fp, "cellparam bandwidth:%s error it should be {0~4294967295}\n", cmd[5]);
            return;
        }
        if(0 != get_uint32(&(cellParam.antenna), cmd[6]))
        {
            fprintf(result_fp, "cellparam antenna:%s error it should be {0~4294967295}\n", cmd[6]);
            return;
        }
        ret = call_C_ConfigCBParam(BMCP_CELL_PARAM,
              (Uint8*) &cellParam, sizeof(cellParam));
        fprintf(result_fp, "Config cellParam, result[%s] arfcn[%u] phyCellId[%u] "
              "subFrameAssignment[%u] specialSubframePatterns[%u] "
              "bandwidth[%u] antenna[%u].\n", get_return_result(ret),
              cellParam.arfcn, cellParam.phyCellId,
              cellParam.subFrameAssignment,
              cellParam.specialSubframePatterns, cellParam.bandwidth,
              cellParam.antenna);
        if(!ret)
        {
            fprintf(result_fp, "Check the setting by: sudo ./debugcmd.sh \"get CBCellParam;\"");
        }
    }else if(strcmp("allpaparam", cmd[0])==0){
        Uint32 mode;
        if(num != 2){
           fprintf(result_fp, "Illegal number of parameters for allpaparam\n");
           return;
        }
        if(0 != get_uint32(&(mode), cmd[1]))
        {
            fprintf(result_fp, "paparam paStatus:%s error it should be {0~4294967295}\n", cmd[1]);
            return;
        }

        if(mode == 10){
          //not SXGP
          if(1 == rf_status) {
          //pradio 0 => 1
          pradioset(1);
          } else {
            pradioset(0);
          }
          //tti open
          char debug_cmd[CMD_NUM*CMD_LENGTH] = {0};
          char* result;
          Uint32 offset = 0;
          offset += sprintf(debug_cmd+offset, "set PackageParam: PackageType = 3;");
          result = call_C_ConfigDebugCmd(debug_cmd);
          oam_syslog("Debugcmd cmd[%s] result:%s\n", debug_cmd, result);
          if(strcmp(result, "success") != 0) {
            oam_syslog("Debugcmd cmd[%s] failure\n",debug_cmd);
#if DEBUGCMD_REBOOT_ENABLE
            monitors_info[debugcmd_monitor_id].reboot_flag = 1;
#endif
            return;
          }

          powerparamset(cb_info.power_param);
          //send to eNB
          union sigval mysigval;
          mysigval.sival_int= SIGNAL_ALL_PRADIO_1;
          sigqueue(eNB_pid,SIGUSR1,mysigval);
          oam_syslog("OAM send SIGUSR1 to eNB pid %d,sival_int %d\n",eNB_pid,mysigval.sival_int);
        }else if(mode == 30){
          //SXGP
          if(1 == rf_status) {
            for(Uint8 i=0;i< pradio_conf_num;i++){
              if(pradio_info.pradio_lanID[i] != 0){
                pradio_info.pradio_sxgp[i] = 3;
              }
            }
            for(Uint8 i=0;i< pradio_conf_num;i++){
              if(pradio_info.pradio_lanID[i] != 0){
                //0 => 3
                ret = onepradioset(pradio_info.pradio_lanID[i],3);
                if(ret == 0){
                  break;
                }
              }
            }

          } else {
            pradioset(0);
          }
          //cellparam FDD
          char debug_cmd[100] = {0};
          char* result;
          Uint32 offset = 0;
          offset += sprintf(debug_cmd+offset, "set CBCellParam: subFrameAssignment=0xFFFF, specialSubframePatterns=0xFFFF;");
          result = call_C_ConfigDebugCmd(debug_cmd);
          oam_syslog("Debugcmd cmd[%s] result:%s\n", debug_cmd, result);
          if(strcmp(result, "success") != 0) {
            oam_syslog("Debugcmd cmd[%s] failure\n",debug_cmd);
#if DEBUGCMD_REBOOT_ENABLE
            monitors_info[debugcmd_monitor_id].reboot_flag = 1;
#endif
            return;
          }

          //tti open
          offset = 0;
          offset += sprintf(debug_cmd+offset, "set PackageParam: PackageType = 3;");
          result = call_C_ConfigDebugCmd(debug_cmd);
          oam_syslog("Debugcmd cmd[%s] result:%s\n", debug_cmd, result);
          if(strcmp(result, "success") != 0) {
            oam_syslog("Debugcmd cmd[%s] failure\n",debug_cmd);
#if DEBUGCMD_REBOOT_ENABLE
            monitors_info[debugcmd_monitor_id].reboot_flag = 1;
#endif
            return;
          }

          //send to eNB
          union sigval mysigval;
          mysigval.sival_int= SIGNAL_ONE_PRADIO_3;
          sigqueue(eNB_pid,SIGUSR1,mysigval);
          oam_syslog("OAM send SIGUSR1 to eNB pid %d,sival_int %d\n",eNB_pid,mysigval.sival_int);
        }else if(mode == 3){
            for(Uint8 i=0;i< pradio_conf_num;i++){
              if(pradio_info.pradio_lanID[i] != 0){
                pradio_info.pradio_sxgp[i] = 3;
              }
            }
            Uint8 first_set3=0;
            for(Uint8 i=0;i< pradio_conf_num;i++){
              if(pradio_info.pradio_lanID[i] != 0){
                //1 => 3
                ret = onepradioset(pradio_info.pradio_lanID[i],3);
                if(ret == 0){
                  first_set3 = i;
                  break;
                }
              }
            }

            for(Uint8 i=first_set3+1;i< pradio_conf_num;i++){
              if(pradio_info.pradio_lanID[i] != 0){
                //1 => 0
                ret = onepradioset(pradio_info.pradio_lanID[i],0);
                if(ret == 0){
                  continue;
                }
              }
            }

            //cellparam FDD
            char debug_cmd[100] = {0};
            char* result;
            Uint32 offset = 0;
            offset += sprintf(debug_cmd+offset, "set CBCellParam: subFrameAssignment=0xFFFF, specialSubframePatterns=0xFFFF;");
            result = call_C_ConfigDebugCmd(debug_cmd);
            oam_syslog("Debugcmd cmd[%s] result:%s\n", debug_cmd, result);
            if(strcmp(result, "success") != 0) {
              oam_syslog("Debugcmd cmd[%s] failure\n",debug_cmd);
#if DEBUGCMD_REBOOT_ENABLE
              monitors_info[debugcmd_monitor_id].reboot_flag = 1;
#endif
              return;
            }

            //send to eNB
            union sigval mysigval;
            mysigval.sival_int= SIGNAL_ONE_PRADIO_3;
            sigqueue(eNB_pid,SIGUSR1,mysigval);
            oam_syslog("OAM send SIGUSR1 to eNB pid %d,sival_int %d\n",eNB_pid,mysigval.sival_int);
        }else{
          oam_syslog("llegal number of parameters for allpaparam\n");
        }
    }
    else if(strcmp("cbcellparam", cmd[0]) == 0){
        Uint32 value;
        if(num != 2){
           fprintf(result_fp, "Illegal number of parameters for allpaparam\n");
           return;
        }
        if(0 != get_uint32(&(value), cmd[1]))
        {
            fprintf(result_fp, "paparam paStatus:%s error it should be {0~4294967295}\n", cmd[1]);
            return;
        }
        if(value == 1){
          //send to eNB
          union sigval mysigval;
          mysigval.sival_int= SIGNAL_CB_CELL_PARAM + last_pradio_num;
          sigqueue(eNB_pid,SIGUSR1,mysigval);
          oam_syslog("OAM send SIGUSR1 to eNB pid %d,sival_int %d\n",eNB_pid,mysigval.sival_int);
        }
    }else if(strcmp("sxgp_result", cmd[0]) == 0){
      Uint32 result;
      if(num != 2){
        fprintf(result_fp, "Illegal number of parameters for sxgp_result\n");
        return;
      }
      if(0 != get_uint32(&(result), cmd[1]))
      {
        fprintf(result_fp, "paparam paStatus:%s error it should be {0~4294967295}\n", cmd[1]);
        return;
      }
      //value
      if((result != 0) && (result != 1) && (result != 2)){
        fprintf(result_fp, "sxgp_result :%d error it should be {0,1,2}\n", result);
        return;
      }
      if(0 == rf_status) {
        pradioset(0);
        union sigval mysigval;
        mysigval.sival_int= SIGNAL_ALL_PRADIO_1;
        sigqueue(eNB_pid,SIGUSR1,mysigval);
        oam_syslog("OAM send SIGUSR1 to eNB pid %d,sival_int %d rf_status %d\n",eNB_pid,mysigval.sival_int, rf_status);
        return;
      }
      //status 3 pradio num
      Uint8 pastatus_num = 0;
      Uint8 pastatus_index[32] = {0};
      for(Uint8 i=0;i< pradio_conf_num;i++){
        if(pradio_info.pradio_status[pradio_info.pradio_lanID[i]/10 -1][pradio_info.pradio_lanID[i]%10-1] == 3){
          pastatus_index[pastatus_num] = i;
          pastatus_num++;
        }
      }

      oam_syslog("receive result %d pastatus_num %d pradio_conf_num %d\n",result,pastatus_num,pradio_conf_num);
      if(result == 2){
        if(pastatus_num == 1){
          pradio_failsafe_num++;
          if(pradio_failsafe_num < pradio_failsafe_maxnum){
            union sigval mysigval;
            if(pastatus_num == pradio_conf_num){
              mysigval.sival_int= SIGNAL_ALL_PRADIO_3;
            }else if(pastatus_num == 1){
              mysigval.sival_int= SIGNAL_ONE_PRADIO_3;
            }
            sigqueue(eNB_pid,SIGUSR1,mysigval);
            oam_syslog("OAM send SIGUSR1 to eNB pid %d,sival_int %d\n",eNB_pid,mysigval.sival_int);
            return;
          }else{
            oam_syslog("pradio %d ul data 0\n",pradio_info.pradio_lanID[pastatus_index[0]]);
            result = 1;
          }
        }else{
          oam_syslog("receive result %d pastatus_num(%d) > 1 error\n",result,pastatus_num);
        }
      }
      pradio_failsafe_num = 0;
        if(pastatus_num == 1){
            Uint8 lanID = pradio_info.pradio_lanID[pastatus_index[0]];
            //pradio set 0
            ret = onepradioset(lanID,0);
            if(ret == 0){
              if(result == 0){
                // pradio lanID  NOT detect
                pradio_info.pradio_sxgp[pastatus_index[0]] = 1;
              }else if(result == 1){
                // pradio lanID  detect
                pradio_info.pradio_sxgp[pastatus_index[0]] = 2;
              }
            }
            Uint8 last_index = 0;
            for(last_index=pastatus_index[0]+1;last_index< pradio_conf_num;last_index++){
              if(pradio_info.pradio_sxgp[last_index] == 3){
                //next pradio set 3
                Uint8 next_lanID = pradio_info.pradio_lanID[last_index];
                ret = onepradioset(next_lanID,3);
                if(ret == 0){
                  //pastatus send to eNB
                  union sigval mysigval;
                  mysigval.sival_int= SIGNAL_ONE_PRADIO_3;
                  sigqueue(eNB_pid,SIGUSR1,mysigval);
                  oam_syslog("OAM send SIGUSR1 to eNB pid %d,sival_int %d\n",eNB_pid,mysigval.sival_int);
                  break;
                }
              }
            }

            if(last_index == pradio_conf_num){
              Uint8 not_detect_num =0;
              for(Uint8 i = 0;i<pradio_conf_num;i++){
                if(pradio_info.pradio_sxgp[i] == 1){
                  not_detect_num++;
                }else if(pradio_info.pradio_sxgp[i] == 2){
                  pradio_info.pradio_sxgp[i] = 0;
                  oam_syslog("LBT Pradio[%d] detect,TX/RX off\n",pradio_info.pradio_lanID[i]);
                }
              }
              if(not_detect_num == 0){
                for(Uint8 i=0;i< pradio_conf_num;i++){
                  if(pradio_info.pradio_lanID[i] != 0){
                    pradio_info.pradio_sxgp[i] = 3;
                  }
                }
                for(Uint8 i=0;i< pradio_conf_num;i++){
                  if(pradio_info.pradio_lanID[i] != 0){
                    //0 => 3
                    ret = onepradioset(pradio_info.pradio_lanID[i],3);
                    if(ret == 0){
                      break;
                    }
                  }
                }
                oam_syslog("LBT restart :not_detect_num 0\n");
                //pastatus send to eNB
                union sigval mysigval;
                if(pradio_conf_num == 1){
                  mysigval.sival_int= SIGNAL_ALL_PRADIO_3;
                }else{
                  mysigval.sival_int= SIGNAL_ONE_PRADIO_3;
                }
                sigqueue(eNB_pid,SIGUSR1,mysigval);
                oam_syslog("OAM send SIGUSR1 to eNB pid %d,sival_int %d\n",eNB_pid,mysigval.sival_int);
              }else if(not_detect_num == 1){
                //cellparam TDD
                cb_info.cell_param.subFrameAssignment = 1;
                cb_info.cell_param.specialSubframePatterns = 0;
                int ret = call_C_ConfigCBParam(BMCP_CELL_PARAM,
                      (Uint8*) &cb_info.cell_param, sizeof(cb_info.cell_param));
                oam_syslog("Config cellParam, result[%s] arfcn[%u] phyCellId[%u] "
                      "subFrameAssignment[%u] specialSubframePatterns[%u] "
                      "bandwidth[%u] antenna[%u].\n", get_return_result(ret),
                                  cb_info.cell_param.arfcn, cb_info.cell_param.phyCellId,
                                  cb_info.cell_param.subFrameAssignment,
                                  cb_info.cell_param.specialSubframePatterns, cb_info.cell_param.bandwidth,
                                  cb_info.cell_param.antenna);
                if(!ret) {
#if CELLPARAM_REBOOT_ENABLE
                  monitors_info[cellparam_monitor_id].reboot_flag = 1;
#endif
                  return;
                }
                //power
                powerparamset(21);
                powerparamset(cb_info.power_param);
                for(Uint8 i = 0;i<pradio_conf_num;i++){
                  if(pradio_info.pradio_sxgp[i] == 1){
                    //pradio set 1
                    ret = onepradioset(pradio_info.pradio_lanID[i],1);
                    if(ret != 0){
                      //pradio num == 0
                      oam_syslog("LBT stop : pradio num 0\n");
                    }
                    break;
                  }
                }
                //pastatus send to eNB
                union sigval mysigval;
                //NOT detect pradio set 1
                if(pradio_conf_num == 1){
                  mysigval.sival_int= SIGNAL_ALL_PRADIO_1;
                }else{
                  mysigval.sival_int= SIGNAL_ONE_PRADIO_1;
                }
                sigqueue(eNB_pid,SIGUSR1,mysigval);
                oam_syslog("OAM send SIGUSR1 to eNB pid %d,sival_int %d\n",eNB_pid,mysigval.sival_int);
                last_pradio_num = 1;
              }else{
                //cellparam TDD
                cb_info.cell_param.subFrameAssignment = 1;
                cb_info.cell_param.specialSubframePatterns = 0;
                int ret = call_C_ConfigCBParam(BMCP_CELL_PARAM,
                      (Uint8*) &cb_info.cell_param, sizeof(cb_info.cell_param));
                oam_syslog("Config cellParam, result[%s] arfcn[%u] phyCellId[%u] "
                      "subFrameAssignment[%u] specialSubframePatterns[%u] "
                      "bandwidth[%u] antenna[%u].\n", get_return_result(ret),
                                  cb_info.cell_param.arfcn, cb_info.cell_param.phyCellId,
                                  cb_info.cell_param.subFrameAssignment,
                                  cb_info.cell_param.specialSubframePatterns, cb_info.cell_param.bandwidth,
                                  cb_info.cell_param.antenna);
                if(!ret) {
#if CELLPARAM_REBOOT_ENABLE
                  monitors_info[cellparam_monitor_id].reboot_flag = 1;
#endif
                  return;
                }
                //power
                powerparamset(21);
                powerparamset(cb_info.power_param);
                for(Uint8 i = 0;i<pradio_conf_num;i++){
                  if(pradio_info.pradio_sxgp[i] == 1){
                    //pradio set 1
                    ret = onepradioset(pradio_info.pradio_lanID[i],1);
                    if(ret != 0){
                      not_detect_num--;
                    }
                  }
                }
                if(not_detect_num == 0){
                  //pradio num == 0
                  oam_syslog("LBT stop : pradio num 0\n");
                }
                last_pradio_num = not_detect_num;
                //pastatus send to eNB
                union sigval mysigval;
                //NOT detect pradio set 1
                if(not_detect_num == pradio_conf_num){
                  mysigval.sival_int= SIGNAL_ALL_PRADIO_1;
                }else{
                  mysigval.sival_int= SIGNAL_PART_PRADIO_1;
                }
                sigqueue(eNB_pid,SIGUSR1,mysigval);
                oam_syslog("OAM send SIGUSR1 to eNB pid %d,sival_int %d\n",eNB_pid,mysigval.sival_int);
              }
            }
        }else{
          fprintf(result_fp, "sxgp_result error: pradio_conf_num %d pradio num %d \n",
                              pradio_conf_num,pastatus_num);
        }
    }else if(strcmp("paparam", cmd[0])==0){
        S_PAParam PAParam;
        if(num != 3){
           fprintf(result_fp, "Illegal number of parameters for paparam\n");
           return;
        }
        if(0 != get_uint32(&(PAParam.lanID), cmd[1]))
        {
            fprintf(result_fp, "paparam lanID:%s error it should be {0~4294967295}\n", cmd[1]);
            return;
        }
        if(0 != get_uint32(&(PAParam.paStatus), cmd[2]))
        {
            fprintf(result_fp, "paparam paStatus:%s error it should be {0~4294967295}\n", cmd[2]);
            return;
        }
#if PAPARAM_RESET_ENABLE
        for(Int8 i = 0;i<3;i++){
#endif
          ret = call_C_ConfigCBParam(BMCP_PA_PARAM,
              (Uint8*) &PAParam, sizeof(PAParam));
          fprintf(result_fp, "Config PAParam, result[%s] lanID[%u] paStatus[%u].\n", get_return_result(ret),
              PAParam.lanID, PAParam.paStatus);
          if(ret)
          {
            pradio_info.pradio_status[PAParam.lanID/10 - 1][PAParam.lanID%10 - 1] = PAParam.paStatus;
            if(0 == PAParam.paStatus)
            {
                fprintf(result_fp, "PRadio[%u] power amplifier turn off.\n", PAParam.lanID);
            }
            else if(1 == PAParam.paStatus)
            {
                fprintf(result_fp, "PRadio[%u] power amplifier turn on.\n", PAParam.lanID);
            }
#if PAPARAM_RESET_ENABLE
            break;
#endif
          }
#if PAPARAM_RESET_ENABLE
          else{
            if(i == 2){
              oam_syslog("Exec_cmd PRadio[%d] set paparam fail: %d -> %d. Pradio offline\n",
                          PAParam.lanID,pradio_info.pradio_status[PAParam.lanID/10 - 1][PAParam.lanID%10 - 1],PAParam.paStatus);
              Int8 j= 0;
              for(j = 0;j<pradio_conf_num;j++){
                if(PAParam.lanID == pradio_info.pradio_lanID[j]){
                  pradio_info.pradio_lanID[j] = 0;
                  pradio_info.pradio_sxgp[j] = 0;
                  pradio_info.pradio_status[PAParam.lanID/10 - 1][PAParam.lanID%10 - 1] = 0;
                  break;
                }
              }
              if(j == pradio_conf_num ){
                  oam_syslog("Exec_cmd PRadio[%d] isnot in pradio list\n",PAParam.lanID);
              }
            }
          }
#endif
        }
    }else if(strcmp("powerparam", cmd[0])==0){
        S_PowerParam powerParam;
        if(num != 3){
           fprintf(result_fp, "Illegal number of parameters for powerparam\n");
           return;
        }
        if(0 != get_uint32(&(powerParam.lanID), cmd[1]))
        {
            fprintf(result_fp, "powerparam lanID:%s error it should be {0~4294967295}\n", cmd[1]);
            return;
        }
        if(0 != get_uint32(&(powerParam.targetPower), cmd[2]))
        {
            fprintf(result_fp, "powerparam targetPower:%s error it should be {0~4294967295}\n", cmd[2]);
            return;
        }
        ret = call_C_ConfigCBParam(BMCP_POWER_PARAM,
              (Uint8*) &powerParam, sizeof(powerParam));
        fprintf(result_fp, "Config powerParam, result[%s] lanID[%u] targetPower[%u].\n", get_return_result(ret),
              powerParam.lanID, powerParam.targetPower);

    }else if(strcmp("timeparam", cmd[0])==0){
        if(num != 4){
           fprintf(result_fp, "Illegal number of parameters for local_timeparam\n");
           return;
        }
        S_TimeParam local_timeParam;
        struct tm set_date;
        //local_timeParam.timestamp = time(NULL);
        sscanf(cmd[1], "%04d-%02d-%02d",
        &set_date.tm_year,
        &set_date.tm_mon,
        &set_date.tm_mday);
        sscanf(cmd[2], "%02d:%02d:%02d",
        &set_date.tm_hour,
        &set_date.tm_min,
        &set_date.tm_sec);
        set_date.tm_year -= 1900;
        set_date.tm_mon -= 1;
        local_timeParam.timestamp = mktime(&set_date);
        snprintf(local_timeParam.localTimeZone, sizeof(local_timeParam.localTimeZone), "%s",
              cmd[3]);
        ret = call_C_ConfigCBParam(BMCP_TIME_PARAM,
              (Uint8*) &local_timeParam, sizeof(local_timeParam));
        fprintf(result_fp, "Config local_timeParam, result[%s] local_timestamp[%u] localTimeZone[%s].\n",
              get_return_result(ret), local_timeParam.timestamp, local_timeParam.localTimeZone);

    }else if(strcmp("upgrade", cmd[0])==0){
        Uint32 Port;
        char *packageFile;
        if(num != 3){
           fprintf(result_fp, "Illegal number of parameters for upgrade\n");
           oam_syslog("Upgrade Result: Illegal number of parameters for upgrade\n");
           return;
        }
        if(0 != get_uint32(&Port, cmd[1]))
        {
            fprintf(result_fp, "upgrade Port:%s error it should be {0~4294967295}\n", cmd[1]);
            return;
        }
        packageFile = cmd[2];

        fprintf(result_fp, "  See result at Monitoring->Latest data->History of syslog after 3 minutes\n");
        fprintf(result_fp, "  Like this : Upgrade Result\n");
        fprintf(result_fp, "  Upgrade may need 10 minutes\n");
        fflush(result_fp);
        ret = call_C_Upgrade(Port, packageFile);
        fseek(result_fp, 0L, SEEK_SET);
        ftruncate(fileno(result_fp), 0);
        fprintf(result_fp, "Upgrade Result: Upgrade cmd result[%s]\n", get_return_result(ret));
        if(ret)
        {
            fprintf(result_fp, "  Upgrade may need 10 minutes\n");
        }
        oam_syslog("Upgrade Result: Upgrade cmd result[%s]\n", get_return_result(ret));

    }else if(strcmp("reboot", cmd[0])==0){
        Uint32 deviceType;
        Uint32 device;
        if(num != 3){
           fprintf(result_fp, "Illegal number of parameters for reboot\n");
           return;
        }
        if(0 != get_uint32(&deviceType, cmd[1]))
        {
            fprintf(result_fp, "reboot deviceType:%s error it should be {0~4294967295}\n", cmd[1]);
            return;
        }
        if(0 != get_uint32(&device, cmd[2]))
        {
            fprintf(result_fp, "reboot device:%s error it should be {0~4294967295}\n", cmd[2]);
            return;
        }
        ret = call_C_RebootDevice(deviceType, device);
        fprintf(result_fp, "Reboot result[%s] deviceType[%u] device[%u]\n", get_return_result(ret), deviceType, device);
        if(ret)
        {
            fprintf(result_fp, "  Reboot may need 8 minutes\n");
            fprintf(result_fp, "  See result at Monitoring->Latest data->History of syslog\n");
            fprintf(result_fp, "  Like this : Now cb connect\n");
        }

    }else if(strcmp("collectlog", cmd[0])==0){
        Uint32 Port;
        Uint32 maxSize;
        char* logFilePath;

        if(num != 4){
           fprintf(result_fp, "Illegal number of parameters for collectlog\n");
           oam_syslog("Collectlog Result: Illegal number of parameters for collectlog\n");
           return;
        }

        if(0 != get_uint32(&Port, cmd[1]))
        {
            fprintf(result_fp, "Collectlog Port:%s error it should be {0~4294967295}\n", cmd[1]);
            return;
        }
        logFilePath = cmd[2];
        if(0 != get_uint32(&maxSize, cmd[3]))
        {
            fprintf(result_fp, "Collectlog maxSize:%s error it should be {0~4294967295}\n", cmd[3]);
            return;
        }
        fprintf(result_fp, "  log file is very large, it may need some time to download it.\n");
        fprintf(result_fp, "  See result at Monitoring->Latest data->History of syslog\n");
        fprintf(result_fp, "  Like this : Collectlog Result:\n");
        fflush(result_fp);
        ret = call_C_CollectLog(Port, logFilePath, maxSize);
        fseek(result_fp, 0L, SEEK_SET);
        ftruncate(fileno(result_fp), 0);
        fprintf(result_fp, "Collectlog result[%s] logFile[%s]\n", get_return_result(ret), logFilePath);
        oam_syslog("Collectlog result[%s] logFile[%s]\n", get_return_result(ret), logFilePath);

    }else if(strcmp("debugcmd", cmd[0])==0){
        if(num == 1){
           fprintf(result_fp, "Illegal number of parameters for debugcmd\n");
           return;
        }
        char debug_cmd[CMD_NUM*CMD_LENGTH] = {0};
        Uint32 id = 1;
        Uint32 offset = 0;
        offset += sprintf(debug_cmd+offset, "%s", cmd[1]);
        for(id = 2; id < num; id++)
        {
           offset += sprintf(debug_cmd+offset, " %s", cmd[id]);
        }
        fprintf(result_fp, "Debugcmd cmd[%s] result:%s\n", debug_cmd, call_C_ConfigDebugCmd(debug_cmd));
        oam_syslog("Debugcmd cmd[%s] result:%s\n", debug_cmd, call_C_ConfigDebugCmd(debug_cmd));
    }else if(strcmp("quit", cmd[0])==0){
        oam_exit = 1;
    }else if(strcmp("tti_disappear", cmd[0])==0){
#if TTI_REBOOT_ENABLE
        monitors_info[ttidisappear_monitor_id].reboot_flag = 1;
#endif
    }else{
        fprintf(result_fp, "Illegal cmd:%s\n", cmd[0]);
    }
}

Int32 oam_fifo_open()
{
    unlink(FIFO_NAME);
    Int32 fifo = 0;
    if(access(FIFO_NAME, 0) != -1){
        //remove(FIFO_NAME);
        printf("%s already exist\n", FIFO_NAME);
        return -1;
    }
    if(mkfifo(FIFO_NAME, 0644) == -1){
        printf("create oam fifo error\n");
        return -1;
    }
//    system("setfacl -m u:zabbix:w /etc/oai/OAMFIFO");
    fifo = open(FIFO_NAME, O_RDWR);
    if(fifo <= 0) {
        printf("open oam fifo error\n");
        return -1;
    }
    return fifo;
}

void sig_handler(int signo)
{
    if (signo == SIGINT){
        printf("signal handler : received SIGINT\n");
        exit_fun();
    } else {
        printf("signal handler : received (%d) signal\n",signo);
    }
}

int main(int argc, char* argv[])
{
    Uint32 ret;
    char buf[CMD_BUFFER_SIZE];
    char cmd[CMD_NUM][CMD_LENGTH];
    FILE *result_fp;
    char log_name[1024] = {0};

    get_conf();
    sprintf(log_name, "%s/%s", log_path, RESULT_LOG_FILE);
    if (signal(SIGINT, sig_handler) == SIG_ERR)
    {
        return -1;
    }

    if(-1 == oam_syslog_open())
    {
        return -1;
    }
    //fifo = oam_fifo_open(FIFO_NAME, O_RDONLY);
    fifo = oam_fifo_open();
    if(-1 == fifo)
    {
        oam_syslog_close();
        return -1;
    }

    //openlog("OAMRadioManager", LOG_CONS | LOG_PID, 0);
    oam_syslog("========OAM Radio Manager Start========\n");
    //show config
    show_conf();

    system("modprobe 8021q");
    system("ifconfig vEth0 up");

    system("vconfig add vEth0 11");
    system("ifconfig vEth0.11 192.168.196.240");

    ret = call_C_StartServer(OAM_IP, OAM_PORT);
    if(ret == 0)
    {
        oam_syslog("start server fail!\n");
        oam_syslog_close();
        oam_fifo_close(fifo);
    }else if(ret == 1)
    {
        oam_syslog("Get lib version[%s]\n", call_C_GetVersion());
        oam_syslog("start server successful!\n");
    }
    call_C_Debug(true);
    call_C_RegisterCBConnectFuncPtr(&CBConnectHandler);
    call_C_RegisterCBOfflineFuncPtr(&CBOfflineHandler);
    call_C_RegisterCBReportParamFuncPtr(&CBReportParamHandler);

    eNB_pid = my_system("pgrep lte-softmodem");
    if(eNB_pid == 0){
        oam_syslog("lte-softmodem not exist\n");
    }
    else if(pradio_conf_num == 0){
        oam_syslog("Don't need LBT : Pradio num 0\n");
    }
    else
    {
        //creat thread
        pthread_t pthread;
        pthread_attr_t attr;
        pthread_attr_init( &attr);
        pthread_create( &pthread, &attr, signal_thread, NULL);
    }

#if REBOOT_ENABLE
    init_monitor_info();
    //creat thread
    pthread_t monitor_pthread;
    pthread_attr_t monitor_attr;
    pthread_attr_init( &monitor_attr);
    pthread_create( &monitor_pthread, &monitor_attr, monitor_thread, NULL);
#endif
#if SYSLOG_REBOOT_ENABLE
    pthread_t syslog_monitor_pthread;
    pthread_attr_t syslog_monitor_attr;
    pthread_attr_init( &syslog_monitor_attr);
    pthread_create( &syslog_monitor_pthread, &syslog_monitor_attr, monitor_syslog_thread, NULL);
#endif
    while(!oam_exit)
    {
        memset(buf, 0, CMD_BUFFER_SIZE);
        memset(cmd, 0, CMD_NUM*CMD_LENGTH);
        ret = read(fifo, buf, CMD_BUFFER_SIZE);
        buf[ret-1] = '\0';
        if(-1 == (access(log_name,F_OK))){
            creat(log_name, 0644);
        }else{
            chmod(log_name, 0644);
        }
        result_fp = fopen(log_name, "w+");
        if(cb_status == CB_CONNECT || strcmp("quit", cmd[0]) == 0 || strcmp("version", cmd[0]) == 0 )
        {
            fprintf(result_fp, "Setting parameters:%s\n", buf);
            oam_syslog("Setting parameters:%s\n", buf);
            ret = split(buf, " ", cmd);
            Exec_cmd(cmd, ret, result_fp);
        }
        else
        {
           fprintf(result_fp, "CB is offline, unable to execute command\n");
        }
        fclose(result_fp);
    }
    exit_fun();
    return 0;
}
