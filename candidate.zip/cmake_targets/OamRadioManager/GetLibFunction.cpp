#include <iostream>
#include <stdlib.h>
#include <memory>
#include <algorithm>
#include <time.h>
#include <cstring>
#include "Common.h"
#include "RadioOAMManager.h"
#include "DataDefine.h"

using namespace std;


extern "C" {
	Uint32 call_C_StartServer(char* s,int i)
	{
		return RadioOAMManager::Instance().StartServer(s,i);
	}

	void call_C_RegisterCBConnectFuncPtr(void  (*func)())
	{
		CBConnectFuncPtr connectPtr(new CBConnectFunc(*func));
		RadioOAMManager::Instance().RegisterCBConnectFuncPtr(connectPtr);
	}

	void call_C_RegisterCBOfflineFuncPtr(void  (*func)())
	{
		CBOfflineFuncPtr offlinePtr(new CBOfflineFunc(*func));
		RadioOAMManager::Instance().RegisterCBOfflineFuncPtr(offlinePtr);
	}

	void call_C_RegisterCBReportParamFuncPtr(void (*func)(Uint32, Uint8*, Uint32))
	{
		CBReportParamFuncPtr paramPtr(new CBReportParamFunc(*func));
		RadioOAMManager::Instance().RegisterCBReportParamFuncPtr(paramPtr);
	}

	Uint32 call_C_ConfigCBParam(Uint32 dataID, Uint8* pData, Uint32 len)
	{
		return RadioOAMManager::Instance().ConfigCBParam(dataID,pData, len);
	}

	Uint32 call_C_Upgrade(Uint32 Port,char *packageFile)
	{
		return RadioOAMManager::Instance().Upgrade(Port, packageFile);
	}

	Uint32 call_C_RebootDevice(Uint32 deviceType, Uint32 device)
	{
		return RadioOAMManager::Instance().RebootDevice(deviceType, device);
	}

	Uint32 call_C_CollectLog(Uint32 Port,char *logFilePath,Uint32 maxSize)
	{
		return RadioOAMManager::Instance().CollectLog(Port, logFilePath,maxSize);
	}

	char* call_C_ConfigDebugCmd(char* s)
	{
		string ret = RadioOAMManager::Instance().ConfigDebugCmd(s);
		char *c = (char *)malloc(ret.length());
		strcpy(c,ret.c_str());
		return c;
	}

	char* call_C_GetVersion()
	{
		string ret = RadioOAMManager::Instance().GetVersion();
		char *c = (char *)malloc(ret.length());
		strcpy(c,ret.c_str());
		return c;
	}

	void call_C_Debug(Uint32 debugSwitch)
	{
		RadioOAMManager::Instance().Debug(debugSwitch);
	}
}
/*  end of file*/
