cd /tmp/oai_test_setup/oai
source oaienv
echo $EXEC $EXEC_ARGS
$EXEC $EXEC_ARGS
