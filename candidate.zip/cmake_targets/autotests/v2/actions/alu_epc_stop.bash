sudo /opt/ltebox/tools/stop_ltebox
