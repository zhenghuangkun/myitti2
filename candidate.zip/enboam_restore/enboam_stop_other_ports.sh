#!/bin/bash
#l1main_ports=(22 2152 50001 50040 255 32123)
names=(ssh aaa bbb)
types=(tcp raw tcp)
ports=(22 255 50005)

name=ENB_PORT_FOR_S1U
port=`grep ENB_PORT_FOR_S1U ../cmake_targets/enb.band39.tm1.25PRB.DAS_BBU1_0dBm.conf |awk BEGIN'{FS="[=; \t]+";OFS="\t"}''{for(i=1;i<=NF;i++){if ("#" == $i) break; else if("ENB_PORT_FOR_S1U" == $i){ print $(i+1);break;}}}'`
names=(${names[@]} ${name})
types=(${types[@]} udp)
ports=(${ports[@]} ${port})

name=ENB_PORT_FOR_X2C
port=`grep ENB_PORT_FOR_X2C ../cmake_targets/enb.band39.tm1.25PRB.DAS_BBU1_0dBm.conf |awk BEGIN'{FS="[=; \t]+";OFS="\t"}''{for(i=1;i<=NF;i++){if ("#" == $i) break; else if("ENB_PORT_FOR_X2C" == $i){ print $(i+1);break;}}}'`
names=(${names[@]} ${name})
types=(${types[@]} udp)
ports=(${ports[@]} ${port})



#sudo iptables -P INPUT DROP
#sudo iptables -P FORWARD DROP
#sudo iptables -P OUTPUT DROP

for id in "${!names[@]}";
do
#    sudo iptables -A INPUT -p ${types[id]} --dport ${ports[id]} -j ACCEPT
#    sudo iptables -A OUTPUT -p ${types[id]} --sport ${ports[id]} -j ACCEPT
     echo ${id}" "${names[id]}""${types[id]}" "${ports[id]}
     id=${id}+1
done

#sudo iptables -L -n
