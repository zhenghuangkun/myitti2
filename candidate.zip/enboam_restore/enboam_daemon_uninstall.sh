#!/bin/bash
sudo iptables -P INPUT ACCEPT
sudo iptables -P FORWARD ACCEPT
sudo iptables -P OUTPUT ACCEPT
sudo iptables -F
sudo rm /lib/systemd/system/oaienb.service /etc/systemd/system/oaienb.service /etc/default/oaienb
sudo rm /lib/systemd/system/oam.service /etc/systemd/system/oam.service
#sudo rm -r /etc/oai /etc/oam
