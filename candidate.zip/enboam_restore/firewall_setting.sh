#!/bin/bash
#l1main_ports=(22 2152 50001 50040 255 32123)

source oaienb
if [ ! -f ${OAI_DIR}/cmake_targets/${CONF_NAME} ];then
    echo ${OAI_DIR}/cmake_targets/${CONF_NAME}": No such file"
    exit
fi

names=(S1AP_PORT_NUMBER)
types=(sctp)
ports=(36412)

names=(${names[@]} SSH)
types=(${types[@]} tcp)
ports=(${ports[@]} 22)

names=(${names[@]} OAMRadioManager)
types=(${types[@]} tcp)
ports=(${ports[@]} 50005)

name=ENB_PORT_FOR_S1U
port=`grep ENB_PORT_FOR_S1U "${OAI_DIR}"/cmake_targets/"${CONF_NAME}" |awk BEGIN'{FS="[=; \t]+";OFS="\t"}''{for(i=1;i<=NF;i++){if ("#" == $i) break; else if("ENB_PORT_FOR_S1U" == $i){ print $(i+1);break;}}}'`
if [[ "" != ${port} ]]
then
    names=(${names[@]} ${name})
    types=(${types[@]} udp)
    ports=(${ports[@]} ${port})
fi

name=ENB_PORT_FOR_X2C
port=`grep ENB_PORT_FOR_X2C "${OAI_DIR}"/cmake_targets/"${CONF_NAME}" |awk BEGIN'{FS="[=; \t]+";OFS="\t"}''{for(i=1;i<=NF;i++){if ("#" == $i) break; else if("ENB_PORT_FOR_X2C" == $i){ print $(i+1);break;}}}'`
if [[ "" != ${port} ]]
then
    names=(${names[@]} ${name})
    types=(${types[@]} sctp)
    ports=(${ports[@]} ${port})
fi

name=dact_send_service_port
port=`grep dact_send_service_port "${OAI_DIR}"/cmake_targets/"${CONF_NAME}" |awk BEGIN'{FS="[=; \t]+";OFS="\t"}''{for(i=1;i<=NF;i++){if ("#" == $i) break; else if("dact_send_service_port" == $i){ print $(i+1);break;}}}'`
if [[ "" != ${port} ]]
then
    names=(${names[@]} ${name})
    types=(${types[@]} udp)
    ports=(${ports[@]} ${port})
fi

sudo iptables -P INPUT DROP
sudo iptables -P FORWARD DROP
sudo iptables -P OUTPUT DROP

for id in "${!names[@]}";
do
    echo " ACCEPT "${names[id]}" port:"
    echo "sudo iptables -A INPUT -p ${types[id]} --dport ${ports[id]} -j ACCEPT"
    sudo iptables -A INPUT -p ${types[id]} --dport ${ports[id]} -j ACCEPT
    echo "sudo iptables -A OUTPUT -p ${types[id]} --sport ${ports[id]} -j ACCEPT"
    sudo iptables -A OUTPUT -p ${types[id]} --sport ${ports[id]} -j ACCEPT
done
sudo iptables -I INPUT -s 127.0.0.0/8 -d 127.0.0.0/8 -j ACCEPT
sudo iptables -I OUTPUT -s 127.0.0.0/8 -d 127.0.0.0/8 -j ACCEPT
#sudo service iptables restart
sudo iptables -L -n
