#!/bin/bash

echo "change oaienb daemon competence..."
source oaienb

if [ -d ${OAI_DIR} ];then
    sudo chmod -R go-rwx ${OAI_DIR}
else
    echo ${OAI_DIR}": No such directory"
fi
