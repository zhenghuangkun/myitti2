#!/bin/sh

#### process name setting ####
proc1="./lte_build_oai/build/lte-softmodem"

#### enb PID setting ####
pid1=`ps -aux | grep ${proc1} | grep -v color | grep -v grep | grep -v sudo | awk '{print $2}'`

loop_max=100
loop=0
zero=0

while true  
do
  sudo kill -2 ${pid1}

  sleep 1

  proc_num1=`ps -aux | grep ${proc1} | grep -v color | grep -v grep | grep -v sudo | wc -l`

  echo loop=$loop 

  if [ $proc_num1 -eq $zero]
  then
    break
  fi

  if [ $loop -ge $loop_max ]
  then
    echo "loop_max!! "
    break
  fi

  loop=$(( loop + 1))

done
