#!/bin/bash

source oaienb
echo "check install files..."
if [ ! -d ${OAI_DIR} ];then
    echo ${OAI_DIR}": No such directory"
    exit
fi
if [ ! -f ${OAI_DIR}/cmake_targets/${CONF_NAME} ];then
    echo ${OAI_DIR}/cmake_targets/${CONF_NAME}": No such file"
    exit
fi
if [ ! -d ${OAM_DIR} ];then
    echo ${OAM_DIR}": No such directory"
    exit
fi

oam_config=${OAM_DIR}/OAMPradioManager.conf
if [ ! -f ${oam_config} ];then
    echo ${oam_config}": No such file"
    exit
fi

# Change folder competence, user group and other users can't read write and execute
#sudo ./change_folder_competence.sh

# Use firewall other ports can't translate data
#sudo ./firewall_setting.sh

echo "oaienb daemon install..."

sudo cp ./oaienb.service /lib/systemd/system/oaienb.service
sudo ln -s /lib/systemd/system/oaienb.service /etc/systemd/system/oaienb.service

sudo cp ./oaienb /etc/default/oaienb

sudo mkdir /etc/oai
sudo chmod 700 /etc/oai/

# script copy
sudo cp ./oaienb_boot.sh /etc/oai/
sudo cp ./oaienb_terminate.sh /etc/oai/

cd /etc/oai/
sudo chmod 700 ./oaienb_boot.sh
sudo chmod 700 ./oaienb_terminate.sh

cd -

sudo systemctl daemon-reload

echo "oaienb daemon installation have finished!!"

echo "oam daemon install..."

sudo cp ./oam.service /lib/systemd/system/oam.service
sudo ln -s /lib/systemd/system/oam.service /etc/systemd/system/oam.service

#sudo cp ./oam /etc/default/oam

sudo mkdir /etc/oam
sudo chmod 700 /etc/oam/

# script copy
sudo cp ./oam_boot.sh /etc/oam/
sudo cp ./oam_terminate.sh /etc/oam/

cd /etc/oam/
sudo chmod 700 ./oam_boot.sh
sudo chmod 700 ./oam_terminate.sh

cd -

sudo systemctl daemon-reload

echo "oam daemon installation have finished!!"

