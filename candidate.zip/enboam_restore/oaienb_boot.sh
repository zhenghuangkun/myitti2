#!/bin/bash
#### process name setting ####
proc2="./OAMRadioManager"

#### oam PID setting ####
pid2=`ps -aux | grep ${proc2} | grep -v color | grep -v grep | grep -v sudo | awk '{print $2}'`

loop_max=100
loop=0
zero=0

while [ $loop -le $loop_max ]
do
  sudo kill -9 ${pid2}

  sleep 1

  proc_num2=`ps -aux | grep ${proc2} | grep -v color | grep -v grep | grep -v sudo | wc -l`

  echo loop=$loop 

  if [ $proc_num2 -eq $zero ]
  then
    echo "kill ${proc2} process ok"
    loop=$loop_max
  fi

#  if [ $loop -ge $loop_max ]
#  then
#    echo "loop_max!! "
#    break
#  fi

  loop=$(( loop + 1))

done

time=`date +%Y%m%d%H%M`

cd ${OAI_DIR}
#cd /etc/oai/openairinterface5g

source oaienv

cd cmake_targets

oai_cmd="sudo -E ./lte_build_oai/build/lte-softmodem -O ${CONF_NAME} --log-mem ${MEMLOG_NAME}_${time} --log-sxgp ${SXGPLOG_NAME}_${time}"
#oai_cmd="sudo -E ./lte_build_oai/build/lte-softmodem -O enb.band38.tm1.25PRB.usrpx310.conf --log-mem /etc/oai/memlog_${time}"


ulimit -c unlimited
result=`ulimit -c`

if [ $result = "unlimited" ]; then
  echo "core dunmp setting OK!" 
else
  echo "core dump setting NG!"
fi


${oai_cmd} &>${CONLOG_NAME}_${time} &
#${oai_cmd} &>/etc/oai/console_${time} &
