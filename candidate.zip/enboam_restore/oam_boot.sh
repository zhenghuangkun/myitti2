#!/bin/bash

#### wait eNB process start ####
proc1="./lte_build_oai/build/lte-softmodem"
loop_max=100
loop=0
zero=0

while [ $loop -le $loop_max ]
do
  proc_num1=`ps -aux | grep ${proc1} | grep -v color | grep -v grep | grep -v sudo | wc -l`

  if [ $proc_num1 -eq $zero ]
  then
    sleep 5
  else
    #wait enb start finish
    sleep 30
    loop=$loop_max
#    break
  fi

#  if [ $loop -ge $loop_max ] 
#  then
#    echo "loop_max!! "
#    break
#  fi

  loop=$(( loop + 1))

done

#### start oam ####
oam_cmd="sudo -E ./OAMRadioManager > /etc/oai/oam.log"

cd ${OAM_DIR}

sudo ./zabbix_script/oam/init_oam.sh
${oam_cmd} &
