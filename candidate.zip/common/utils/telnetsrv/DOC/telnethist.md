The telnet server implements a simple history system
```bash
softmodem> telnet history list
1: telnet history list
2: telnet history list
3: help
4: loader show modules
5: softmodem show loglvl
6: help
7: telnet history
8: help
9: telnet history list
10: help
11: loader show modules
12: softmodem show loglvl
13: softmodem log help
14: softmodem log disable 0-35
15: softmodem log show
16: help
17: telnet history list
18: loader show modules
19: softmodem thread show
20: help
21: softmodem thread help
22: softmodem log show
23: softmodem log help
24: softmodem log level_error 0-4
25: loader show modules
26: loader show config
27: help
28: loader show params
29: loader show modules
softmodem> !28
softmodem>  loader show params
loader parameters:
   Main executable build version: "Branch: develop-telnet-loader-fixes Abrev. Hash: e56ae69 Date: Fri Mar 9 16:47:08 2018 +0100"
   Default shared lib path: ""
   Max number of shared lib : 10
softmodem>

```

[oai telnetserver home](telnetsrv.md)
[oai telnetserver usage home](telnetusage.md)
