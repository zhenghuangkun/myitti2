int T_stdout;

void exit_function(const char *file, const char *function, const int line, const char *s) {
}
