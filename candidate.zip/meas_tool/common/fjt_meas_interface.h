#ifndef __FJT_MEAS_INTERFACE_H__  /*  __FJT_MEAS_INTERFACE_H__ */
#define __FJT_MEAS_INTERFACE_H__ /*  __FJT_MEAS_INTERFACE_H__ */

#include "fjt_meas_common_auto.h"

uint32_t fjt_meas_cfg_init(void);
uint32_t fjt_meas_cfg_close(void);
uint32_t fjt_meas_cfg_load_config(const char* filepath);

void fjt_meas_dact_getconfig(void);
void fjt_meas_dact_mem_free(void);

void fjt_meas_main( void* input_param);
void fjt_meas_finish(void);

uint32_t fjt_meas_ringbuff_create(uint32_t server_flag);
uint32_t fjt_meas_ringbuff_write(uint8_t item_id, void* value, uint8_t opt1, uint8_t opt2, uint8_t opt3, uint8_t opt4);

/*******************/
/* extern          */
/*******************/

//sync pthead
extern pthread_cond_t subframe_sync_cond;
extern pthread_mutex_t subframe_sync_mutex;

// easy pps shaper: extern
extern int  write_sfn;
extern int  write_subframe;

extern int g_dact_collection;

#endif /*  __FJT_MEAS_INTERFACE_H__ */
