
#ifndef __FJT_MEAS_COMMON_AUTO_H__
#define __FJT_MEAS_COMMON_AUTO_H__

#include <stddef.h> // for NULL
#include <stdint.h>
#include <stdlib.h>
#include <sys/time.h>

//
// define parameter
//
#define FJT_MEAS_FLAG_ON (1)
#define FJT_MEAS_FLAG_OFF (0)
#define FJT_MEAS_BUFF_SIZE (8)
#define FJT_MEAS_ITEM_SIZE_BYTE (16)
#define FJT_MEAS_ITEM_SIZE_BIT (4)

// parameter for filter
#define FJT_MEAS_FILTER_DISCARD (0) // 破棄
#define FJT_MEAS_FILTER_FORWARD (1) // 送信
#define FJT_MEAS_FILTER_NO_PARAM (0)
#define FJT_MEAS_FILTER_PARAM (1)

//
// define macro-function
//
#define __FJT_MEAS_ATTR_ALIGN(SIZE) __attribute__ (( aligned(SIZE) ))

//
// define service flag
//
#define PRE_THREAD_FLAG (0x0001<<0)
#define RXTX_THREAD_FLAG (0x0001<<1)
#define RRC_THREAD_FLAG (0x0001<<2)
#define GTP_THREAD_FLAG (0x0001<<3)
#define S1AP_THREAD_FLAG (0x0001<<4)
#define X2AP_THREAD_FLAG (0x0001<<5)
#define THREAD_FLAG_MASK (PRE_THREAD_FLAG | RXTX_THREAD_FLAG | RRC_THREAD_FLAG | GTP_THREAD_FLAG | S1AP_THREAD_FLAG | X2AP_THREAD_FLAG)

//
// define type
//
//
// define enum
//
typedef enum tag_e_fjt_meas_server {
    INVALID_SRV = 0,
    UE_MAIN_SRV,
    ENB_MAIN_SRV,
    MAX_MAIN_SRV
} fjt_meas_server_t;

typedef enum tag_e_fjt_meas_item {
    ITEM_INVALID = 0,
    #define ITEM_INFO(item_name, id, name_str, data_size, data_num, target_server_flag)         id,
    #include "fjt_meas_item_list.h"
    #undef ITEM_INFO
    FJT_MEAS_ITEM_NUM
} fjt_meas_item_t;

#define FJT_MEAS_CONF_NUM (FJT_MEAS_ITEM_NUM)  //5 json config info without items' number

typedef enum tag_e_fjt_meas_return_value {
    FJT_MEAS_RET_OK = 0,
    FJT_MEAS_RET_ERR = 1,
    FJT_MEAS_RET_FATAL = 2
} fjt_meas_return_value_t;

typedef enum tag_e_fjt_meas_conf_type {
    CONF_TYPE_OBJ = 0,
    CONF_TYPE_INT = 1,
    CONF_TYPE_NUM = 2,
    CONF_TYPE_IP = 3
} fjt_meas_conf_type_t;

//
// define struct
//
typedef struct tag_fjt_meas_item_info {
    uint32_t    data_num;        //測定値のデータ数
    uint16_t    data_size;       //測定値のサイズ
    uint16_t    use_factor_num;  //使用する要素数
    uint16_t    target_server_flag;   //測定対象のサーバ種別
    uint8_t     reserve[6];      // for alignment
} fjt_meas_item_info_t;

typedef struct tag_fjt_meas_pkt_header {
    uint16_t    pkt_type;
    uint16_t    server_type;
    uint16_t    enb_id;
    uint8_t     reserve[2]; /* for alignment */
} fjt_meas_pkt_header_t;

typedef struct tag_fjt_meas_sf_header {
    uint16_t         next_flag;
    uint16_t         factor_num;
    uint32_t         timestamp_sf;
    struct timeval  timestamp;  /* <sys/time.h> 16byte */
    // struct timeval {
    //     time_t      tv_sec;   // time_t      = long; 8byte
    //     suseconds_t tv_usec;  // suseconds_t = long; 8byte
    // }
} fjt_meas_sf_header_t;

typedef struct tag_fjt_meas_item_header {
    uint8_t    next_flag;  //続フラグ
    uint8_t    item_id;    //項目ID
    uint16_t   item_size;  //測定値サイズ
    uint8_t    opt1;       //OPT1
    uint8_t    opt2;       //OPT2
    uint8_t    opt3;       //OPT3
    uint8_t    opt4;       //OPT4
} fjt_meas_item_header_t;

typedef struct tag_fjt_meas_item_data {
   union{ //要素毎のヘッダ情報
         fjt_meas_item_header_t  info;
         uint64_t    info_all;
    };
    uint64_t  value;      //測定値
} fjt_meas_item_data_t;

typedef struct tag_fjt_meas_conf_item_info {
    uint8_t  level;      /* 階層 */
    uint8_t  data_type;  /* データ種別(fjt_meas_conf_type_t) */
    uint8_t  data_size;
    uint8_t  reserve[5]; /* for 64-bits alignment */
    const char*   conf_name;
    void*   value_p;      /* Global変数へのポインタ */
} fjt_meas_conf_item_info_t;

typedef struct tag_fjt_meas_filter {
    uint8_t  filter;
    uint8_t  filter_param;
} fjt_meas_filter_t;

typedef struct tag_fjt_meas_filter_param_info {
    union {
        uint8_t   param[4]; /* filter Opt1-4 */
        uint32_t  param_word32;
    };
    union {
        uint8_t   mask[4];
        uint32_t  mask_word32;
    };
} fjt_meas_filter_param_info_t;

typedef union tag_fjt_meas_dest_addr_info {
    union {
        struct {
            union {
                uint8_t   ip_byte[4];
                uint32_t  ip_word32; /* for data-copy and comparison */
            };
            uint16_t  port;
            uint8_t   active;
            uint8_t   specific_port;
        } __FJT_MEAS_ATTR_ALIGN(8);
        uint64_t  word64;
    };
} fjt_meas_dest_addr_info_t;

typedef struct tag_fjt_meas_dest_file_info {
    union {
        struct {
            uint32_t file_size;
            uint16_t file_num;
        } __FJT_MEAS_ATTR_ALIGN(8);
        uint64_t  word64;
    };
} fjt_meas_dest_file_info_t;

typedef struct tag_fjt_meas_sender_info {
    fjt_meas_dest_addr_info_t  pc_info;
    fjt_meas_dest_file_info_t  file_info;
    uint32_t  MTU;
    uint32_t  subframe_interval;
} fjt_meas_sender_info_t __FJT_MEAS_ATTR_ALIGN(64);

typedef enum tag_e_rrc_item
{
  RRC_CONNECTION_REQUEST_TYPE_ID,
  RRC_CONNECTION_SETUP_TYPE_ID,
  RRC_CONNECTION_SETUP_COMPLETE_TYPE_ID,
  RRC_CONNECTION_CONFIGURATION_TYPE_ID,
  RRC_CONNECTION_CONFIGURATION_COMPLETE_TYPE_ID,
  RRC_CONNECTION_RELEASE_TYPE_ID,
  RRC_REESTABLISHMENT_REQUEST_TYPE_ID,
  RRC_REESTABLISHMENT_TYPE_ID,
  RRC_REESTABLISHMENT_COMP_TYPE_ID
}rrc_msg_type_id_e;

typedef enum tag_e_s1ap_item
{
  S1AP_ENB_HANDLE_S1_PATH_SWITCH_REQUEST_ACK_REQ_TYPE_ID     =10,
  S1AP_ENB_HANDLE_S1_PATH_SWITCH_REQUEST_FAILURE_REQ_TYPE_ID =11,
  S1AP_ENB_HANDLE_E_RAB_SETUP_REQUEST_REQ_TYPE_ID            =15,
  S1AP_ENB_HANDLE_E_RAB_MODIFY_REQUEST_REQ_TYPE_ID           =18,
  S1AP_ENB_HANDLE_E_RAB_RELEASE_COMMAND_REQ_TYPE_ID          =21,
  S1AP_ENB_HANDLE_INITIAL_CONTEXT_REQUEST_REQ_TYPE_ID        =27,
  S1AP_ENB_HANDLE_PAGING_REQ_TYPE_ID                         =30,
  S1AP_ENB_HANDLE_NAS_DOWNLINK_REQ_TYPE_ID                   =33,
  S1AP_ENB_HANDLE_ERROR_INDICATION_REQ_TYPE_ID               =45,
  S1AP_ENB_HANDLE_S1_SETUP_RESPONSE_REQ_TYPE_ID              =52,
  S1AP_ENB_HANDLE_S1_SETUP_FAILURE_REQ_TYPE_ID               =53,
  S1AP_ENB_HANDLE_UE_CONTEXT_RELEASE_COMMAND_REQ_TYPE_ID     =69,
  S1AP_ENB_HANDLE_DEACTIVATE_TRACE_REQ_TYPE_ID               =78,
  S1AP_ENB_HANDLE_TRACE_START_REQ_TYPE_ID                    =81
}s1ap_msg_type_id_e;

typedef enum tag_e_x2ap_item
{
  X2AP_ENB_HANDLE_HANDOVER_PREPARATION_REQ_TYPE_ID           =0,
  X2AP_ENB_HANDLE_HANDOVER_RESPONSE_REQ_TYPE_ID              =1,
  X2AP_ENB_HANDLE_HANDOVER_CANCEL_REQ_TYPE_ID                =3,
  X2AP_ENB_HANDLE_UE_CONTEXT_RELEASE_REQ_TYPE_ID             =15,
  X2AP_ENB_HANDLE_X2_SETUP_REQUEST_REQ_TYPE_ID               =18,
  X2AP_ENB_HANDLE_X2_SETUP_RESPONSE_REQ_TYPE_ID              =19,
  X2AP_ENB_HANDLE_X2_SETUP_FAILURE_REQ_TYPE_ID               =20
}x2ap_msg_type_id_e;

//
// define table
//
extern const fjt_meas_item_info_t Fjt_meas_item_info_table[FJT_MEAS_ITEM_NUM];
extern fjt_meas_filter_t Fjt_meas_filter[FJT_MEAS_ITEM_NUM];
extern fjt_meas_filter_param_info_t Fjt_meas_filter_param[FJT_MEAS_ITEM_NUM];
extern fjt_meas_sender_info_t Fjt_meas_sender_info;
extern const fjt_meas_conf_item_info_t Fjt_meas_conf_item_info[FJT_MEAS_CONF_NUM];

//sync pthead
//extern pthread_cond_t subframe_sync_cond;
//extern pthread_mutex_t subframe_sync_mutex;


#endif /*  __FJT_MEAS_COMMON_AUTO_H__ */

