
#include "fjt_meas_common_auto.h"
#define NUMBER_OF_UE_MAX 256

const fjt_meas_item_info_t Fjt_meas_item_info_table[FJT_MEAS_ITEM_NUM] = {
    {1, 1, 1, INVALID_SRV} /* ITEM_INVALID */,
    #define ITEM_INFO(item_name, id, name_str, data_size, data_num, target_server_flag)          {data_num, data_size, ((data_size%FJT_MEAS_BUFF_SIZE)==0 ? (data_size/FJT_MEAS_BUFF_SIZE) : (data_size/FJT_MEAS_BUFF_SIZE +1)), target_server_flag},
    #include "fjt_meas_item_list.h"
    #undef ITEM_INFO
};

fjt_meas_filter_t Fjt_meas_filter[FJT_MEAS_ITEM_NUM];
fjt_meas_filter_param_info_t Fjt_meas_filter_param[FJT_MEAS_ITEM_NUM];
fjt_meas_sender_info_t Fjt_meas_sender_info;

const fjt_meas_conf_item_info_t Fjt_meas_conf_item_info[FJT_MEAS_CONF_NUM] = {
    #if 1
    #define ITEM_INFO(item_name, id, name_str, data_size, data_num, target_server_flag)          {0, CONF_TYPE_INT, 1, {id}, item_name, &(Fjt_meas_filter[id].filter)},
    #include "fjt_meas_item_list.h"
    #undef ITEM_INFO
    #else
    {0, CONF_TYPE_INT, 1, {ITEM_DL_PDCP_LAT, ITEM_DL_PDCP_PDU, 0, 0, 0}, "dl pdcp item", 1},
    {0, CONF_TYPE_INT, 1, {ITEM_DL_RLC_DRB, ITEM_DL_RLC_RET, 0, 0, 0}, "dl rlc item", 1},
    {0, CONF_TYPE_INT, 1, {ITEM_DL_MAC_RBG_MAPPING, ITEM_DL_MAC_SINR, 0, 0, 0}, "dl mac item", 1},
    {0, CONF_TYPE_INT, 1, {ITEM_UL_PDCP_LAT, ITEM_UL_PDCP_PDU, 0, 0, 0}, "ul pdcp item", 1},
    {0, CONF_TYPE_INT, 1, {ITEM_UL_RLC_DRB, ITEM_UL_RLC_RET, 0, 0, 0}, "ul rlc item", 1},
    {0, CONF_TYPE_INT, 1, {ITEM_UL_MAC_SR, ITEM_UL_MAC_TBS, 0, 0, 0}, "ul mac item", 1},
    #endif
};
