/****************************************************************************************
 *
 * Project     : vRAN
 * Target      : DACT
 *
 * File Name   : fjt_meas_comm.c
 *
 * Description : OAI測定ツール・UDPパケット送信モジュール
 *
 * History     :
 *   2017-01-13 QNET)ikeda    新規作成
 *
 *                                                 Copyright FUJITSU LIMITED 2017
 *
 ****************************************************************************************/

#include "fjt_meas_comm.h"
#include "fjt_meas_stopwatch.h"
#include "common/utils/LOG/log.h"
extern volatile int  oai_exit;

/**
 * Global vars
 */
static fjt_meas_socket_list_t Sockets;

/**
 * @brief initialize
 * @details initialize communication module
 * @return Success(0) or Fail(1)
 */
uint32_t fjt_meas_com_init(void)
{
    fjt_meas_socket_list_t socket_list_initval = {0};

    Sockets = socket_list_initval;

    return FJT_MEAS_RET_OK;
}

/**
 * @brief closing communication module
 * @details close sockets
 * @return Success(FJT_MEAS_RET_OK) or Fail
 */
uint32_t fjt_meas_com_close(void) {
    int err_no;
    fjt_meas_return_value_t rv = FJT_MEAS_RET_OK;

    if(Sockets.socket != 0) {
       LOG_D(MEAS_TOOL, "release socket: socket=%d\n", Sockets.socket);
       err_no = close(Sockets.socket);

        if(err_no != 0) {
            err_no = errno;
            LOG_E(MEAS_TOOL, "could not close socket: socket=%d, errno=%d\n", Sockets.socket, err_no);
            rv = FJT_MEAS_RET_ERR;
        }
    }

    return rv;
}


/**
 * @brief create USP sockets
 * @details sockets are created per destination PC
 * @return Success(0) or Fail(not 0; fjt-error=1, socket-bind-error=-1)
 */
uint32_t fjt_meas_com_create_sockets(void)
{
    int new_sock;
    struct sockaddr_in addr;
    int sock_err;

    /* check active-flag on sender info table */
    if(Fjt_meas_sender_info.pc_info.active == 1) {

        /* create new socket */
        new_sock = socket(AF_INET, SOCK_DGRAM, 0);
        if(new_sock == -1)
        {
            LOG_E(MEAS_TOOL, "create socket error\n");
            return FJT_MEAS_RET_FATAL;
        }

        addr.sin_family = AF_INET;
        addr.sin_port = htons(Fjt_meas_sender_info.pc_info.port);
        addr.sin_addr.s_addr = Fjt_meas_sender_info.pc_info.ip_word32;
                               // ip_word32はデータセット時に aton() 処理

        /* connect */
        LOG_D(MEAS_TOOL, "try create socket's information\n");
        LOG_D(MEAS_TOOL, " -- IP address =  %s\n", inet_ntoa(addr.sin_addr));
        LOG_D(MEAS_TOOL, " -- port = %d\n", ntohs(addr.sin_port));

        sock_err = connect(new_sock, (struct sockaddr*)&addr, sizeof(addr));
        if(0 != sock_err) {
            sock_err = errno;
            // errno 必ずは 0 以外
            LOG_D(MEAS_TOOL, "socket errno: %d", sock_err);
        }

        if(0 != sock_err)
        {
            LOG_E(MEAS_TOOL, "socket connect error\nplease check config file\n");
            return FJT_MEAS_RET_FATAL;
        }

        Sockets.socket = new_sock;
        Sockets.addr = Fjt_meas_sender_info.pc_info;

        /* set socket id */
        LOG_D(MEAS_TOOL, "set socket-id [%d]\n", Sockets.socket);
    }

    return FJT_MEAS_RET_OK;
}


/**
 * @brief send packet
 * @details send UDP packet
 *
 * @param packet pointer of payload data
 * @param size data size [byte]
 * @return Success(0) or Fail(1)
 */
uint32_t fjt_meas_com_send_packet(void* packet, uint32_t size)
{
    ssize_t err = 0;
    int err_no;

    int sock = Sockets.socket;

    FJT_MEAS_STOPWATCH_DEFINE_VAR(time);

    if( -1 == sock )
    {
        LOG_E(MEAS_TOOL, "dest-id to socket table collapsed\n");
        return FJT_MEAS_RET_ERR;
    }

    FJT_MEAS_STOPWATCH_START(time);

    err = send(sock, packet, size, 0);
    FJT_MEAS_STOPWATCH_STOP(time);

    if(err < 0) {
        err_no = errno;
        if(err_no == ECONNREFUSED) {
            LOG_E(MEAS_TOOL, "connection refused, check network and GUI-application\n");
        } else {
            LOG_E(MEAS_TOOL, "packet send error: errno=%d\n", err_no);
        }

        return FJT_MEAS_RET_ERR;
    }

    return FJT_MEAS_RET_OK;
}

