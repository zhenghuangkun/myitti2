
/****************************************************************************************
 *
 * Project     : vRAN
 * Target      : DACT
 *
 * File Name   : fjt_meas_comm.h
 *
 * Description : OAI測定ツール・UDPパケット送信モジュール
 *
 * History     :
 *   2017-01-13 QNET)ikeda    新規作成
 *
 *                                                 Copyright FUJITSU LIMITED 2017
 *
 ****************************************************************************************/

#ifndef __FJT_MEAS_COMM_H__
#define __FJT_MEAS_COMM_H__

#include "fjt_meas_common_auto.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>

/**
 * define parameter
 */


/**
 * define struct
 */
typedef struct tag_fjt_meas_socket_list {
    int socket;
    uint8_t reserve[4]; /* for alignment */
    fjt_meas_dest_addr_info_t addr;
} fjt_meas_socket_list_t;

/**
 * define prototype
 */
uint32_t fjt_meas_com_init(void);
uint32_t fjt_meas_com_close(void);
uint32_t fjt_meas_com_create_sockets(void);
uint32_t fjt_meas_com_send_packet(void* packet, uint32_t size);

#endif /* __FJT_MEAS_COMM_H__ */
