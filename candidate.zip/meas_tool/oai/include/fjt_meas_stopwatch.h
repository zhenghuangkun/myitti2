
/****************************************************************************************
 *
 * Project     : vRAN
 * Target      : DACT
 *
 * File Name   : fjt_meas_stiowatch.h
 *
 * Description : OAI測定ツール・時間測定用マクロ定義
 *
 * History     :
 *   2017-01-13 QNET)ikeda    新規作成
 *
 *                                                 Copyright FUJITSU LIMITED 2017
 *
 ****************************************************************************************/

#ifndef __FJT_MEAS_STOPWATCH_H__
#define __FJT_MEAS_STOPWATCH_H__

#include "fjt_meas_common_auto.h"
#include <stdio.h>
#include <stdlib.h>

/**
 * 時間計測マクロ
 */
#define FJT_MEAS_STOPWATCH_EN (0) /* 1: enabled, others: disabled */
#define FJT_MEAS_STOPWATCH_SAMPLES_BITS (10) /* 測定箇所毎の取得サンプル数 */
#define FJT_MEAS_STOPWATCH_COUNTS (32) /* 最大測定箇所数 */

#if(FJT_MEAS_STOPWATCH_EN == 1) && defined(__x86_64__)
  #if defined(__GNUC__) && (__GNUC__ >= 4)
      #pragma GCC push_options
      #pragma GCC optimize("O0")
  #endif

    // define internal types
    typedef unsigned long long fjt_meas_cpu_clock_t;

    typedef struct {
        volatile fjt_meas_cpu_clock_t begin;
        volatile fjt_meas_cpu_clock_t end;
    } fjt_meas_cpu_clocks_t;

    typedef struct {
        volatile unsigned int count __FJT_MEAS_ATTR_ALIGN(16);
        volatile fjt_meas_cpu_clocks_t* volatile clks_p;
    } fjt_meas_get_cpu_clock_t;

    // Global vars
    extern fjt_meas_get_cpu_clock_t* Fjt_meas_stopwatches[ FJT_MEAS_STOPWATCH_COUNTS ];
    extern uint32_t Fjt_meas_stopwatch_num;

    // define internal funcs
    static inline fjt_meas_cpu_clock_t fjt_meas_get_cpu_clock(void) {
        unsigned int hi; /* timestamp high */
        unsigned int lo; /* timestamp low */
        __asm__ volatile ("rdtscp" : "=a"(lo), "=d"(hi));
        return ((fjt_meas_cpu_clock_t)hi << 32) | (fjt_meas_cpu_clock_t)lo;
    }

    static inline fjt_meas_cpu_clock_t fjt_meas_get_cpu_clock_low(void) {
        unsigned int lo;
        __asm__ volatile ("rdtscp" : "=a"(lo));
        return (fjt_meas_cpu_clock_t)lo;
    }

    static inline void fjt_meas_set_cpu_clock_to_begin(fjt_meas_get_cpu_clock_t* p) {
        fjt_meas_cpu_clocks_t* volatile clks_p = (fjt_meas_cpu_clocks_t* volatile)p->clks_p + p->count;
        clks_p->begin = fjt_meas_get_cpu_clock();
    }

    static inline void fjt_meas_set_cpu_clock_to_end(fjt_meas_get_cpu_clock_t* p) {
        fjt_meas_cpu_clocks_t* volatile clks_p = (fjt_meas_cpu_clocks_t* volatile)p->clks_p + p->count;
        clks_p->end = fjt_meas_get_cpu_clock();
        p->count = (p->count + 1) & (volatile unsigned int)((1u << FJT_MEAS_STOPWATCH_SAMPLES_BITS) - 1u);
    }

    static inline void fjt_meas_init_cpu_clock_vars(volatile fjt_meas_get_cpu_clock_t** pp) {
        *pp = (volatile fjt_meas_get_cpu_clock_t*)malloc(sizeof(fjt_meas_get_cpu_clock_t));
        (*pp)->clks_p = (fjt_meas_cpu_clocks_t* volatile)malloc( (1u << FJT_MEAS_STOPWATCH_SAMPLES_BITS) * sizeof(fjt_meas_cpu_clocks_t) );
        (*pp)->count = 0;
        Fjt_meas_stopwatches[Fjt_meas_stopwatch_num] = (fjt_meas_get_cpu_clock_t*)(*pp);
        LOG_D(MEAS_TOOL, "set stopwatch: id=%d, addr=%p\n", Fjt_meas_stopwatch_num, *pp);
        Fjt_meas_stopwatch_num++; /* マルチスレッド未考慮 */
    }
  #if defined(__GNUC__) && (__GNUC__ >= 4)
      #pragma GCC pop_options
  #endif

    // define Macros
    #define FJT_MEAS_STOPWATCH_DEFINE_VAR(VAR) \
        static volatile fjt_meas_get_cpu_clock_t* volatile VAR = NULL; \
        do { \
            if( VAR == NULL ) { \
                fjt_meas_init_cpu_clock_vars( (volatile fjt_meas_get_cpu_clock_t**)&VAR ); \
            } \
        } while(0)

    #define FJT_MEAS_STOPWATCH_START(VAR) \
        do { \
            fjt_meas_set_cpu_clock_to_begin( (fjt_meas_get_cpu_clock_t*)VAR ); \
        } while(0)

    #define FJT_MEAS_STOPWATCH_STOP(VAR) \
        do { \
            fjt_meas_set_cpu_clock_to_end( (fjt_meas_get_cpu_clock_t*)VAR ); \
        } while(0)

#else
    // dummy
    #define FJT_MEAS_STOPWATCH_DEFINE_VAR(VAR) /* do nothing */
    #define FJT_MEAS_STOPWATCH_START(VAR) /* do nothing */
    #define FJT_MEAS_STOPWATCH_STOP(VAR) /* do nothing */

#endif

// prototype
void fjt_meas_stopwatch_print(void);
uint32_t fjt_meas_stopwatch_close(void);

#endif /* __FJT_MEAS_STOPWATCH_H__ */
