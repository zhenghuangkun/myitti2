/****************************************************************************************
 *
 * Project     : vRAN
 * Target      : DACT
 *
 * File Name   : fjt_meas_ringbuff.h
 *
 * Description : OAI測定ツール リングバッファモジュールヘッダ
 *
 * History     :
 *   2017-01-13   新規作成
 *
 *                                                 Copyright FUJITSU LIMITED 2017
 *
 ****************************************************************************************/

#ifndef __FJT_RINGUBUFF_MODULE_HEADER__
#define __FJT_RINGUBUFF_MODULE_HEADER__

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "fjt_meas_common_auto.h"

/*******************/
/* Define          */
/*******************/
#define FJT_OAI_THREAD_MAX             (100)
#define FJT_RBUFF_DATA_KEEP_SUBFRAME   (3)
#define FJT_4BYTE_BITNUM               (32)
#define FJT_4BYTE_TOPBIT_STAND_VALUE   (0x80000000)
#define FJT_TRASH_REMOVE_MASK_PTN      (9)

/*******************/
/* struct          */
/*******************/
typedef struct tag_fjt_rbuff_write{
    uint32_t   write_index;   //リングバッファのwriteインデックス
    uint8_t    pad[60];       //キャッシュライン調整用
    pthread_mutex_t mutex;    //for write_index
}fjt_rbuff_write_t;

typedef struct tag_fjt_rbuff_read{
    fjt_meas_item_data_t*   rbuff_p;      //リングバッファの先頭ポインタ
    uint32_t                 factor_num;  //要素数
    uint32_t                 cyclic_mask; //サイクリック用マスク値
    uint32_t                 read_index;  //readインデックス
}fjt_rbuff_read_t;

typedef struct tag_fjt_rbuff_read_all{
    fjt_rbuff_read_t    info[FJT_OAI_THREAD_MAX];   //リングバッファ情報
    uint32_t             oai_thread_num;             //リングバッファを生成したOAIスレッドの数
}fjt_rbuff_read_all_t;

typedef struct tag_fjt_rbuff_read_local{
    uint32_t     thread_index;                           //現在の読み込み中のリングバッファ
    uint32_t     write_index[FJT_OAI_THREAD_MAX];        //ローカルのwriteインデックス
}fjt_rbuff_read_local_t;

/*******************/
/* Function Proto  */
/*******************/
uint32_t fjt_meas_roundup_power_of_two(uint32_t input_num);
uint32_t fjt_meas_ringbuff_create(uint32_t server_flag);
uint32_t fjt_meas_ringbuff_write(uint8_t item_id, void* value, uint8_t opt1, uint8_t opt2, uint8_t opt3, uint8_t opt4);
uint32_t fjt_meas_ringbuff_init(void);
void fjt_meas_ringbuff_free(void);
uint32_t fjt_meas_ringbuff_read_ready(void);
uint32_t fjt_meas_ringbuff_get_item_info(fjt_meas_item_header_t* output_p);
uint32_t fjt_meas_ringbuff_copy_item_to_buff(uint8_t* send_buff_p, uint32_t max_factor_num);

#endif  /*__FJT_RINGUBUFF_MODULE_HEADER__*/
