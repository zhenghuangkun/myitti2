/****************************************************************************************
 *
 * Project     : vRAN
 * Target      : DACT
 *
 * File Name   : fjt_meas_main.h
 *
 * Description : OAI測定ツール mainヘッダ
 *
 * History     :
 *   2017-01-13   新規作成
 *
 *                                                 Copyright FUJITSU LIMITED 2017
 *
 ****************************************************************************************/

#ifndef __FJT_MAIN_MODULE_HEADER__
#define __FJT_MAIN_MODULE_HEADER__

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif /*_GNU_SOURCE*/

#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/sysinfo.h>
#include "fjt_meas_common_auto.h"
#include "fjt_meas_comm.h"
#include "fjt_meas_save_file.h"
#include "fjt_meas_config.h"
#include "fjt_meas_measure.h"
#include "fjt_meas_packet.h"
#include "fjt_meas_ringbuff.h"

/*******************/
/* Define          */
/*******************/
#define FJT_MEAS_CORE_UE            (15)    //UEサーバの測定機能割当コア番号
#define FJT_MEAS_CORE_ENB            (9)    //サーバの測定機能割当コア番号
#define FJT_MEAS_SFN_MASK           (1023)  //SFN有効ビットのマスク値
/*******************/
/* struct          */
/*******************/
typedef struct tag_fjt_meas_main_input{
    uint16_t     server_kind;
    uint16_t     enb_id;
    int*         sfn_p;
    int*         subframe_p;
}fjt_meas_main_input_t;

/*******************/
/* Function Proto  */
/*******************/
void fjt_meas_main( void* input_param);

/*******************/
/* extern          */
/*******************/
extern int              sync_var;
extern pthread_cond_t   sync_cond;
extern pthread_mutex_t  sync_mutex;

// easy pps shaper: extern
extern int  write_sfn;
extern int  write_subframe;
//

#endif  /*__FJT_MAIN_MODULE_HEADER__*/





