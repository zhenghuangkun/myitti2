/****************************************************************************************
 *
 * Project     : vRAN
 * Target      : DACT
 *
 * File Name   : fjt_meas_config.h
 *
 * Description : OAI測定ツール・コンフィグファイル読み込みモジュール
 *
 * History     :
 *   2017-01-13 QNET)ikeda    新規作成
 *
 *                                                 Copyright FUJITSU LIMITED 2017
 *
 ****************************************************************************************/

#ifndef __FJT_MEAS_CONFIG_H__
#define __FJT_MEAS_CONFIG_H__

#include "fjt_meas_common_auto.h"
#include "parson/parson.h"

#include "common/utils/LOG/log.h"

#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/**
 * define parameter
 */


/**
 * define struct
 */



/**
 * define prototype
 */
uint32_t fjt_meas_cfg_init(void);
uint32_t fjt_meas_cfg_close(void);
uint32_t fjt_meas_cfg_load_config(const char* filepath);


#endif /* __FJT_MEAS_CONFIG_H__ */
