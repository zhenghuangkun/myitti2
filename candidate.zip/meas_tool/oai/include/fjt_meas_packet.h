/****************************************************************************************
 *
 * Project     : vRAN
 * Target      : DACT
 *
 * File Name   : fjt_meas_packet.h
 *
 * Description : OAI測定ツール・パケットデータ生成モジュール
 *
 * History     :
 *   2017-01-13 QNET)ikeda    新規作成
 *
 *                                                 Copyright FUJITSU LIMITED 2017
 *
 ****************************************************************************************/

#ifndef __FJT_MEAS_PACKET_H__
#define __FJT_MEAS_PACKET_H__

#include "fjt_meas_common_auto.h"
#include "fjt_meas_comm.h"
#include "fjt_meas_save_file.h"
#include "fjt_meas_ringbuff.h"
#include <math.h>
#include <string.h>

/**
 * define parameter
 */
#define FJT_MEAS_PKT_BUF_SIZE (16*1024) /* 16KBytes */
#define FJT_MEAS_PKT_HEADER_LEN (6+6+2+20+8+4) /* MAC-DA, MAC-SA, Ethertype, IP, UDP, FCS */

#define FJT_MEAS_PKT_TS_SFN_LSFT  (8)           /* timestamp領域用のSFN 左シフト数 */
#define FJT_MEAS_PKT_TS_SFN_MASK  (0xffffff00)  /*                      マスク値   */
#define FJT_MEAS_PKT_TS_SUBF_LSFT (0)           /* timestamp領域用のSubf左シフト数 */
#define FJT_MEAS_PKT_TS_SUBF_MASK (0xff)        /*                      マスク値   */

/**
 * define struct
 */
typedef struct tag_fjt_meas_sf {
    uint32_t sfn;
    uint32_t subframe;
} fjt_meas_sf_t;

// information of packet buffers
typedef struct tag_fjt_meas_packet_info {
    uint8_t*         pkt_buf_p;
    uint16_t         data_size;
    uint16_t         mtu;
    uint8_t          reserve[4];
    fjt_meas_sf_t   prev_sf;
    fjt_meas_sf_header_t* prev_sf_header_p;
} fjt_meas_packet_info_t;

/**
 * define prototype
 */
uint32_t fjt_meas_pkt_init(void);
uint32_t fjt_meas_pkt_close(void);
uint32_t fjt_meas_pkt_set_packet_info(uint16_t server_type, uint16_t enb_id);
uint32_t fjt_meas_pkt_copy_item_to_packet(uint32_t sfn, uint32_t subf, uint32_t item_id);
uint32_t fjt_meas_pkt_check_packet_send_timeout(uint32_t sfn, uint32_t subf, uint32_t sfn_mask);

#endif /* __FJT_MEAS_PACKET_H__ */
