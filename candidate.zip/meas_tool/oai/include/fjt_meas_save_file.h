#ifndef __FJT_MEAS_SAVE_FILE_H__
#define __FJT_MEAS_SAVE_FILE_H__

/**
 * define prototype
 */

/**
 * @brief Write data to memory
 * @details Write data to memory, if one side memory is full, send signal to flush thread, then change to other side write.
 * @param data save data
 * @param size data size
 */
void fjt_meas_data_output_memory(const char* data, int size);
/**
 * @brief Initialization dact memory.
 * @details Create DACT_MEME_SIDE_NUM sides buffer, and create fjt_meas_flush_data_mem_to_file_thread.
 */
void fjt_meas_dact_mem_init (void);

/**
 * @brief Destroy dact memory.
 * @details Flush data from 2 sides buffer to file. Then free2 sides buffer.
 */
void fjt_meas_dact_mem_free(void);
#endif /* __FJT_MEAS_SAVE_FILE_H__ */
