<table style="border-collapse: collapse; border: none;">
  <tr style="border-collapse: collapse; border: none;">
    <td style="border-collapse: collapse; border: none;">
      <a href="http://www.openairinterface.org/">
         <img src="../../doc/images/oai_final_logo.png" alt="" border=3 height=50 width=150>
         </img>
      </a>
    </td>
    <td style="border-collapse: collapse; border: none; vertical-align: center;">
      <b><font size = "5">OAI CI Dev documentation</font></b>
    </td>
  </tr>
</table>

VM-based RF-Less Environment:

*  [How to setup your test env](./vm_based_simulator_env.md)
*  [How to deal with OAI source files](./vm_based_simulator_sources.md)
*  [The main script](./vm_based_simulator_main_scripts.md)
*  [How to create one or several VM instances](./vm_based_simulator_create.md)
*  [How to build an OAI variant](./vm_based_simulator_build.md)
*  [How the build is checked](./vm_based_simulator_check_build.md)
*  [How to test an OAI variant](./vm_based_simulator_test.md)
*  [How to destroy all VM instances](./vm_based_simulator_destroy.md)

Currently missing documentation:
*  How to generate a build report
*  How to generate a test report

---

