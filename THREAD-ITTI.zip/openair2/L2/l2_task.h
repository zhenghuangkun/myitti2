/*
  Author: zhenghuangkun
*/

#ifndef L2_TASK_H_
#define L2_TASK_H_


void *l2_task(void *arg);


#endif
