/*
 * l1_messages_def.h
 *
 *  Created on: Dec 31, 2019
 *      Author: zhenghuangkun
 */

//-------------------------------------------------------------------------------------------//
// Messages between L1 and L3 layers
MESSAGE_DEF(RRC_MAC_IN_SYNC_IND,        MESSAGE_PRIORITY_MED_PLUS, RrcMacInSyncInd,             rrc_mac_in_sync_ind)

