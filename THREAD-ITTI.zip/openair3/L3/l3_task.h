/*
  Author: zhenghuangkun
*/

#ifndef L3_TASK_H_
#define L3_TASK_H_


void *l3_task(void *arg);


#endif
