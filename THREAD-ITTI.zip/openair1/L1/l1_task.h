/*
  Author: zhenghuangkun
*/

#ifndef L1_TASK_H_
#define L1_TASK_H_

void *l1_task(void *arg);


#endif
